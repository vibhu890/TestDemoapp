

$(function () {
    // include html files
    var includes = $('[data-include]');
    $.each(includes, function () {
        var file = $(this).data('include') + '.html'
        var currPage = ($(this).data('active')) ? '.' + $(this).data('active') : '';
        $(this).load(file, function (_data) {
            if (file == 'auth-header.html') { // active header
                $(currPage).addClass('active');
            }
        })
    })

});

$(document).ajaxStop(function () { 
    initCutstomDataTable();
    customMultiSelect('.customMultiSelect', '');
    showCurrentYear();  
    adminSideMenuFn(); 
    stepper()    
    filterRow();   
});

$(document).ready(function () {
    initializeSelect2();
    initializeSelect2ForResponsive();
    applyAriaAttributesToSelect2();
    initCalendar()
    
    $('.dashcardWidgets .Itemscol').matchHeight();
      
       
    $("#clientfileForm").validate({
    submitHandler: function (form) {
        event.preventDefault();
        window.location.href = "client-services.html";
        return false; // Prevent form submission    
    },
    rules: {
        bookClient: {
            required: true
        },
        clientID: {
            required: true
        },
        clientCode: {
            required: true
        },
        clientName: {
            required: true
        },
        sicCode: {
            required: true
        }
    },    
    errorElement: 'p',
    errorPlacement: function (error, element) {
        error.addClass('error-text');
        error.appendTo(element.closest('.form-group'));
        applyErrorAriaDescribedby();
    }

    });  
   
});

function initCutstomDataTable() {
    let customTable = new DataTable('.customTable', {
        paging: true,
        info: true,
        lengthChange: true,
        searching: true,
        responsive: true,
        retrieve: true,
        scrollX: true,
        dom: 'rt<"bottom paginationCol firstLastPagination"<"lenghtCol"l><"pagingCol"p>><"clear">',
        language: {
            "lengthMenu": "Display Rows_MENU_",
            "paginate": {
                "first": '<i class="fa-regular fa-angle-left"></i><i class="fa-regular fa-angle-left"></i>',
                "last": '<i class="fa-regular fa-angle-right"></i><i class="fa-regular fa-angle-right"></i>',
                "previous": '<i class="fa-regular fa-angle-left"></i>',
                "next": '<i class="fa-regular fa-angle-right"></i>',
            }
        },
        orderCellsTop: true,
        fixedHeader: true,
        order: [],
        columnDefs: [
            { orderable: false, targets: 'noSort' } // Disable sorting for columns with 'no-sort' class
        ],
        pagingType: 'full',
        rowCallback: function (row, data, index) {
            if ($(row).hasClass('filterRow')) {
                $(row).attr('data-order', ''); 
            }
        },
        drawCallback: tblPaginateDrawCallback,
    });
}
 