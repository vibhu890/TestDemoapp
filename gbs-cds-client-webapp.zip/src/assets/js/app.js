$.validator.setDefaults({
  errorElement: 'p', // Set the error element to <p>
  errorPlacement: function (error, element) {
    // Add custom error class
    error.addClass('error-text');
    // Place error within the closest .form-group
    error.appendTo(element.closest('.form-group'));
  }
});

// Handle row actions: Add, Edit, and Delete
function handleRowActions(action, $table) {
  if (action === "addRow") {
    const $tableBody = $table.find("tbody");
    const $templateRow = $table.find("tr:last").clone(); // Clone the last row as a template

    // Clear values and prepare the row for new input
    $templateRow.find("td").each(function () {
      const $cell = $(this);

      if (!$cell.hasClass("actionsColumn")) {
        // Check if the cell has a data-type of "select"
        if ($cell.data("type") === "select") {
          const options = $cell.data("options")?.split(",") || []; // Get the options from data-options
          const selectHTML = `
            <select class="form-select otherSelect">
            <option>Select an Option</option>
              ${options.map(option => `<option value="${option}">${option}</option>`).join("")}
            </select>`;
          $cell.html(selectHTML); // Replace the cell content with the select menu
        } else {
          // Default behavior for other cells (e.g., plain text inputs)
          $cell.html('<input type="text" class="form-control" value="">');
        }
      } else if ($cell.data("type") === "muliselect") {
        const options = $cell.data("options").split(","); // Get options from data-options

        // Generate the multi-select HTML control for add row
        const multiSelectHTML = `
          <div class="Selectcontainer customMultiSelect">
            <div class="selected-values form-select" tabindex="0" aria-haspopup="true" aria-expanded="false" aria-label="Choose an option" role="combobox">
              <span class="valueDisplay">Select One</span>
            </div>
            <div class="dropdown-options" id="dropdownOptions1">
              <div class="checkItem">
                <div class="form-group">
                  <input type="checkbox" name="OptionAll" id="OptionAll" class="optionAll">
                  <label for="OptionAll">All</label>
                </div>
              </div>
              ${options.map((option, index) => {
          return `
                    <div class="checkItem">
                      <div class="form-group">
                        <input type="checkbox" name="Option${index}" id="Option${index}">
                        <label for="Option${index}">${option}</label>
                      </div>
                    </div>`;
        }).join("")}
            </div>
          </div>`;

        $cell.html(multiSelectHTML); // Replace the cell content with the custom control
        customMultiSelect();
      } else {
        // Reset the dropdown in the Actions column
        const dropdownHTML = `
          <div class="form-group mb-0">
            <select class="form-select otherSelect" aria-label="actions">
              <option>Select an Action</option>
              <option value="actionEdit">Edit</option>
              <option value="actionDelete">Delete</option>
              <option value="actionActivate">Activate</option>
            </select>
          </div>`;
        $cell.html(dropdownHTML);
      }
    });

    // Append the cloned row to the table body
    $tableBody.append($templateRow);

    // Reinitialize Select2 for all dropdowns, including the new one
    initializeSelectTable($templateRow);
  }
  if (action === "editRow") {
    const $row = $table.find(".editing"); // Target the row to edit

    $row.find("td").each(function () {
      const $cell = $(this);

      if (!$cell.hasClass("actionsColumn")) {
        const cellText = $cell.text().trim(); // Get the current text of the cell

        if ($cell.data("type") === "select") {
          const options = $cell.data("options")?.split(",") || []; // Get the options from data-options

          // Generate the select dropdown with options
          const selectHTML = `
            <select class="form-select">
              <option>Select an Option</option> <!-- First option as 'Select an Option' -->
              ${options
              .map(option => {
                // Mark the option as selected if it matches the current cell text
                return `<option value="${option}" ${option === cellText ? "selected" : ""}>${option}</option>`;
              })
              .join("")}
            </select>`;

          $cell.html(selectHTML); // Replace the cell content with the select menu
        } else if ($cell.data("type") === "muliselect") {
          const options = $cell.data("options").split(","); // Get options from data-options
          const selectedOptions = cellText.split(","); // The current selected options

          // Generate the multi-select HTML control for edit row with selected options
          const multiSelectHTML = `
            <div class="Selectcontainer customMultiSelect has-selection">
              <div class="selected-values form-select" tabindex="0" aria-haspopup="true" aria-expanded="true" aria-label="Choose an option" role="combobox">
                <span class="selected-tag">${selectedOptions.map(option => `${option}<span role="button" class="remove-tag" title="remove tag"><i class="fa-regular fa-xmark"></i></span>`).join(", ")}</span>
              </div>
              <div class="dropdown-options" id="dropdownOptions1">
                <div class="checkItem">
                  <div class="form-group">
                    <input type="checkbox" name="OptionAll" id="OptionAll" class="optionAll">
                    <label for="OptionAll">All</label>
                  </div>
                </div>
                ${options.map((option, index) => {
            const isChecked = selectedOptions.includes(option) ? "checked" : "";
            return `
                      <div class="checkItem">
                        <div class="form-group">
                          <input type="checkbox" name="Option${index}" id="Option${index}" ${isChecked}>
                          <label for="Option${index}">${option}</label>
                        </div>
                      </div>`;
          }).join("")}
              </div>
            </div>`;

          $cell.html(multiSelectHTML); // Replace the cell content with the custom control
          customMultiSelect()
        } else {
          // Default behavior for other cells (e.g., plain text input fields)
          $cell.html(`<input type="text" class="form-control" value="${cellText}">`);
        }
      }
    });

    // Update dropdown in the Actions column to indicate editing state
    $row.find(".otherSelect").val("actionEdit");

    // Initialize Select2 only for the edited row
    initializeSelectTable($row);
  }



  if (action === "deleteRow") {
    const $row = $table.find(".deleting"); // Target the row to delete
    $('#teamsDeleteModal').modal('show');
    $('.deleteRecord').on('click', function () {
      $row.remove(); // Remove the row
    });

  }
}



function applyAriaAttributesToSelect2() {
  setTimeout(() => {
    $(".customSelect, .otherSelect").each(function () {
      var $this = $(this);

      // Get the Select2 container
      var select2Container = $this.next('.select2').find('.select2-selection');

      // Get the ID of the current select or assign one if not present
      var selectId = $this.attr('id') || 'select2-' + Math.random().toString(36).substr(2, 9);
      $this.attr('id', selectId);

      // Check if the select2 is inside a table cell (td)
      var tableCell = $this.closest('td');
      if (tableCell.length) {
        // Get the corresponding column header (th) text
        var columnHeader = tableCell.closest('table').find('th').eq(tableCell.index());
        if (columnHeader.length) {
          var columnHeaderText = columnHeader.text().trim();
          // Remove aria-labelledby and add aria-label
          select2Container.removeAttr('aria-labelledby');
          select2Container.attr('aria-label', columnHeaderText);
        }
      } else {
        // Handle the case where the select2 is outside a table
        var label = $this.prev('label');
        if (label.length) {
          // Check if the label contains a child element with class 'labelTxt'
          var labelTxt = label.find('.labelTxt');
          var labelTarget = labelTxt.length ? labelTxt : label;

          var labelId = labelTarget.attr('id') || 'label-' + selectId;
          labelTarget.attr('id', labelId);

          // Add aria-labelledby to the Select2 container
          select2Container.attr('aria-labelledby', labelId);
        }
      }

      // Add aria-required if the select is required
      if ($this.prop('required')) {
        select2Container.attr('aria-required', 'true');
      }
    });
  }, 1000);

}
function applyErrorAriaDescribedby() {
  setTimeout(() => {
    $(".customSelect").each(function () {
      var $this = $(this);

      // Get the Select2 container
      var select2Container = $this.next('.select2').find('.select2-selection');

      if ($this.parents('.form-group').find('.error')) {
        var errorId = $this.parents('.form-group').find('p.error').attr('id')
        select2Container.attr('aria-describedby', errorId)
      }

    });
  }, 1000);
}


// Helper function to detect touch devices
function isTouchDevice() {
  return 'ontouchstart' in window || navigator.maxTouchPoints > 0 || navigator.msMaxTouchPoints > 0;
}

// Run the function when the page is loaded or resized




let filterData = [];
// Handle row filter
function filterRow() {
  $('.filterRow').each(function () {
    $(this).find('td').each(function (cellIndex) {
      const $cell = $(this);
      const $multiSelectDropdown = $cell.find('.Selectcontainer');
      const isMultiSelectInCell = $multiSelectDropdown.length > 0;
      const $currentTable = $cell.closest('table');
      // Check if multiselect dropdown is in the cell to prevent from event listeners being added to checkboxes inside it
      if (isMultiSelectInCell) {
        // const target = $multiSelectDropdown.find('.selected-values').first()[0];
        $multiSelectDropdown.find('input[type="checkbox"]').each(function () {
          function addToFilterData() {
            if ($(this).is(':checked')) {
              filterData.push($(this).siblings('label').text().trim());
            } else {
              filterData = filterData.filter(item => item !== $(this).siblings('label').text().trim())
            }
            const filterPattern = filterData.join('|');
            // Apply the search to the table
            $currentTable.DataTable().search(filterPattern, true, false).draw();  // Use 'search' to filter all rows based on selected values
          }
          $(this).off('change', addToFilterData);
          $(this).on('change', addToFilterData);
        })
      } else {
        $cell.find('input, select').each(function () {
          if ($(this).attr('id') === 'bulkcheckall') return;
          if ($(this).hasClass('datepicker-range')) {
            $(this).on('apply.daterangepicker', function (ev, picker) {
              $(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'))
              filter($currentTable, cellIndex, $(this).val().replace(" - ", " to "))
            });
          } else if ($(this).hasClass('datepicker')) {
            $(this).on('apply.daterangepicker', function (ev, picker) {
              $(this).val(picker.startDate.format('MM/DD/YYYY'))
              filter($currentTable, cellIndex, $(this).val())
            });
          } else if ($(this).hasClass('datepicker-time')) {
            $(this).on('apply.daterangepicker', function (ev, picker) {
              $(this).val(picker.startDate.format('DD/MM/YYYY h:mm:ss A'))
              filter($currentTable, cellIndex, $(this).val().toLowerCase())
            });
          } else {
            $(this).on('keyup change', function () {
              filter($currentTable, cellIndex, $(this).val().toLowerCase())
            })
          }
        })
      }
    })
  })

  $('.clearFilter').click(function () {
    filter($(this).parents('.clearFiltersBox').next('.tableOuter').find('table'), 0, '')
    $(this).parents('.clearFiltersBox').next('.tableOuter, .pageListTableOuter').find('.filterRow input, .filterRow select').each(function (index) {
      $(this).val('')
    })
    $('body').find('.dropdown-options').each(function (index) {
      const $selectContainer = $(this);  // Corrected 'this' reference
      $selectContainer.find('input[type="checkbox"]').prop('checked', false).trigger('change')
    })
    $(this).parents('.clearFiltersBox').next('.tableOuter, .filterTable').find('.filterRow .otherSelect, .filterRow input').each(function (index) {
      $(this).val(null).trigger('change');
    })
  });
  $('.filterTable thead th').each(function (index) {
    var width = $(this).outerWidth(); // Get width of the header column
    $('.filterTable tbody tr td:nth-child(' + (index + 1) + ')').css('min-width', width + 'px');
    $('.filterTable tbody tr td:nth-child(' + (index + 1) + ')').css('max-width', width + 'px');
    $('.filterTable tbody tr td:nth-child(' + (index + 1) + ')').css('word-break', 'break-all');
    $('.filterTable tbody tr td:nth-child(' + (index + 1) + ')').css('white-space', 'normal');
  });

  // $('.configtable thead th').each(function (index) {
  //   var width = $(this).outerWidth(); // Get width of the header column
  //   $('.configtable tbody tr td:nth-child(' + (index + 1) + ')').css('min-width', width + 'px');
  //   $('.configtable tbody tr td:nth-child(' + (index + 1) + ')').css('max-width', width + 'px');
  //   $('.configtable tbody tr td:nth-child(' + (index + 1) + ')').css('word-break', 'break-all');
  //   $('.configtable tbody tr td:nth-child(' + (index + 1) + ')').css('white-space', 'normal');
  // });

}
var rowSpantext = ''
// Handle filter
function filter(currTable, index, filterValue) {
  var rowCount = 0
  if (!currTable.hasClass('.noFilter')) {
    if (currTable.hasClass('rowSpanTable')) {
      rowSpantext = currTable.find('.rowSpanCell').length ? currTable.find('.rowSpanCell').text().trim() : rowSpantext
    }
    $(currTable).find('tbody tr:not(.filterRow)').each(function () {
      var cellText = $(this).find(`td:nth-child(${index + 1})`).text().toLowerCase();
      // If filterValue is an array of strings
      if (Array.isArray(filterValue)) {
        const matchesFilter = filterValue.some(val => cellText.includes(val.toLowerCase()));
        if (matchesFilter || filterValue.length === 0) {
          $(this).show();
          rowCount++;
        } else {
          $(this).hide();
        }
      }
      else {
        // Default single value check (existing logic)
        if (cellText.includes(filterValue.toLowerCase()) || filterValue === '') {
          $(this).show();
          rowCount++;
        } else {
          $(this).hide();
        }
      }
    });

    if (currTable.hasClass('rowSpanTable')) {
      currTable.find('tr:not(.filterRow)').each(function () {
        $(this).find('td').first().removeAttr('colspan')
        $(this).find('td').first().text('')
        $(this).find('td').first().removeClass('rowSpanCell')
        $(this).find('td').first().addClass('d-none')
      })
      if (rowCount) {
        $(currTable).find('tbody tr.filterRow').find('td').first().addClass('rowSpanfiltercell')
        let firstVisibleRow = $(currTable).find('tbody tr:not(.filterRow):visible').first()
        firstVisibleRow.find('td').first().attr('rowspan', rowCount)
        firstVisibleRow.find('td').first().text(rowSpantext)
        firstVisibleRow.find('td').first().removeClass('d-none')
        firstVisibleRow.find('td').first().addClass('rowSpanCell')
      }
      else {
        $('td.rowSpanfiltercell').removeClass('rowSpanfiltercell')
      }

    }
  }
}

function updateSelectedDisplay(selectedValues, dropdownOptions, placeholderText, activeClass, selectContainer, selectAllLabelText) {
  const selected = [];
  const $selectedOptions = $(dropdownOptions).find('input[type="checkbox"]:not(.optionAll):checked'); // Get all dropdown option checkboxes except 'All' option
  const $selectAllCheckbox = $(dropdownOptions).find('input[type="checkbox"].optionAll'); // Get 'All' checkbox

  // Run only if there is 'All' option present in checkbox options
  if ($selectAllCheckbox.length) {
    if ($selectedOptions.length === $(dropdownOptions).find('input[type="checkbox"]:not(.optionAll)').length) { // Check if selected options count is equal to total options except 'All'
      $selectAllCheckbox.prop("checked", true).next('label').attr('aria-checked', true); // Check 'All' checkbox
      $(selectedValues).empty(); // Clear the previous tags
      $(selectedValues).append(`<span class="valueDisplay">${selectAllLabelText}</span>`); // Append 'All' value to tags
      if ($selectAllCheckbox.prop("checked")) $(selectContainer).addClass(`${activeClass} allSelected`); // Add classname to prevent padding change due to 'has-selection' class
      return;
    }
    // If selected options count is NOT equal to total options except 'All', update checkbox state to not selected
    $selectAllCheckbox.prop('checked', false).next('label').attr('aria-checked', false);
    if (!$selectAllCheckbox.prop('checked')) $(selectContainer).removeClass('allSelected'); // Remove class added for precenting padding change
  }
  $(selectedValues).not('.selectedValuesFB').empty();
  $selectedOptions.each(function () {
    const label = $(this).next('label').text();
    label !== selectAllLabelText ? selected.push(label) : "";

    // Create a tag element for each selected item
    const $tag = $(`<span class="selected-tag" tabindex="0"></span>`).text(label);
    const $removeIcon = $('<span role="button" class="remove-tag" tabindex="0" title="remove tag"><i class="fa-regular fa-xmark"></i></span>');

    // Add a remove handler to each tag
    $removeIcon.on('click keypress', () => {
      $(this).prop('checked', false).trigger('change'); // Uncheck and trigger change
    });
    $tag.append($removeIcon);
    $(selectedValues).append($tag);
  });

  // Show placeholder if no items are selected
  if (selected.length === 0) {
    $(selectedValues).append(`<span class="valueDisplay">${placeholderText}</span>`);
    $(selectContainer).removeClass(activeClass); // Remove class if no selection  
  } else {
    $(selectContainer).addClass(activeClass); // Add class if there are selections
  }
}


function customMultiSelect(selector, appendToSelector = null) {
  $(selector).each(function (index) {
    const $selectContainer = $(this);
    const $selectedValues = $selectContainer.find('.selected-values');
    const $dropdownOptions = $selectContainer.find('.dropdown-options');
    const $searchBox = $selectContainer.find('.search-box input');
    const isTableChild = $selectContainer.closest('td').length > 0;
    const isFormChild = $selectContainer.closest('form');
    let placeholderText = isTableChild ? '' : 'Select One or More';
    const activeClass = 'has-selection';
    const selectAllLabelText = "All";

    if ($selectedValues.data('placeholder')) {
      placeholderText = $selectedValues.data('placeholder');
    }

    // Move dropdown to the specified container if appendToSelector is set
    if (appendToSelector) {
      $dropdownOptions.appendTo($(appendToSelector));
    }

    function updateDropdownPosition() {
      if (appendToSelector) {
        const offset = $selectContainer.offset();
        const height = $selectedValues.outerHeight();
        if (appendToSelector != 'body') {
          offset.top = 0;
          offset.left = 0;
        }
        //console.log($selectContainer,offset,height)
        $dropdownOptions.css({
          position: "absolute",
          top: offset.top + height,
          left: offset.left,
          width: $selectContainer.outerWidth(),
          zIndex: 99
        });
      }
    }

    // Toggle dropdown visibility
    $selectedValues.on('click keypress', function (e) {
      e.preventDefault();
      $('.dropdown-options').not($dropdownOptions).hide(); // Hide other open dropdowns
      $dropdownOptions.toggle();

      $(this).attr('aria-expanded', function (index, attr) {
        return attr === 'false' ? 'true' : 'false';
      });

      $searchBox.val('').trigger('input'); // Clear search on dropdown open

      if ($dropdownOptions.is(':visible')) {
        updateDropdownPosition();
      }
    });

    // Reposition dropdown on window resize or scroll
    $(window).on('resize scroll', function () {
      if ($dropdownOptions.is(':visible')) {
        updateDropdownPosition();
      }
    });

    // Handle checkbox change to update selected items display
    $dropdownOptions.find('input[type="checkbox"]').on('change', function () {
      if ($(this).next().text() === selectAllLabelText) {
        const isChecked = $(this).prop("checked");
        $dropdownOptions.find('input[type="checkbox"]:not(.optionAll)')
          .prop("checked", isChecked)
          .trigger("change");
      }

      updateSelectedDisplay($selectedValues, $dropdownOptions, placeholderText, activeClass, $selectContainer, selectAllLabelText);

      const checkboxes = $selectContainer[0].querySelectorAll('input[type="checkbox"]');
      const isAnyChecked = Array.from(checkboxes).some((checkbox) => checkbox.checked);

      if (isAnyChecked) {
        $selectedValues.removeClass(`error`);
      } else {
        if (!isTableChild && !isFormChild) $selectedValues.addClass(`error`);
      }
    });

    // Search functionality
    $searchBox.on('input', function () {
      const searchTerm = $(this).val().toLowerCase();
      $dropdownOptions.find('.checkItem').each(function () {
        const label = $(this).find('label').text().toLowerCase();
        $(this).toggle(label.indexOf(searchTerm) > -1);
      });
    });

    // Hide dropdown if clicked outside
    $(document).on('click', function (e) {
      if (!$(e.target).closest($selectContainer).length && !$(e.target).closest($dropdownOptions).length) {
        $dropdownOptions.hide();
        $selectedValues.attr('aria-expanded', false);
      }
    });

    // Initial display update
    updateSelectedDisplay($selectedValues, $dropdownOptions, placeholderText, activeClass, $selectContainer, selectAllLabelText);
  });
}


// Example usage:
// Call with appendTo = 'body' if needed
//customMultiSelect('body');


function inputWithDropdown() {
  // Custom input field with dropdown

  $('.inputWithDropdown').each(function () {
    const $this = $(this);
    const $comboInput = $this.find('input').first();
    const $comboMenuContainer = $(this).find('.combo-menu-container').first();
    const $comboMenu = $this.find('.combo-menu').first();
    const $comboOptions = $comboMenu.find('.combo-option');
    const $clearIcon = $(this).find('.clearsearch-inputdrop');
    const $noItemsOption = $(this).find('.combo-option.no-items').first();
    const $headCell = $comboMenuContainer.find('.headCell').first();

    // Toggle dropdown visibility
    function toggleDropdown(open) {
      const isExpanded = open !== undefined ? open : $comboInput.attr('aria-expanded') === 'false';
      $comboInput.attr('aria-expanded', isExpanded);
      $comboMenuContainer.toggleClass('open', isExpanded);  // This will control visibility
      $comboOptions.attr('tabindex', isExpanded ? 0 : -1);
    }


    // Close dropdown if clicked outside
    function closeDropdownOnOutsideClick(event) {
      if (!$this[0].contains(event.target)) toggleDropdown(false);
    }

    // Navigate options using arrow keys
    function moveOptionsWithArrowKeys(event) {
      const $focusedOption = $comboMenu.find(':focus');
      let $nextOption;

      if (event.key === 'ArrowDown') {
        $nextOption = $focusedOption.next('.combo-option');
        if (!$nextOption.length) $nextOption = $comboOptions.first();
      } else if (event.key === 'ArrowUp') {
        $nextOption = $focusedOption.prev('.combo-option');
        if (!$nextOption.length) $nextOption = $comboOptions.last();
      }

      if ($nextOption) $nextOption.focus();
    }

    // Select the currently focused option
    function selectOption($option) {
      // debugger;
      toggleDropdown(false);
      $comboInput.focus();
      if (!$option.is($noItemsOption)) {
        if ($option.find('.clientName').length > 0) {
          $comboInput.val($option.find('.clientName').text().trim());
        } else {
          $comboInput.val($option.text().trim());
        }

      }
    }

    // Focus on the selected or first option
    function focusOnSelectedOrFirstOption() {
      const $selectedOption = $comboMenu.find('.combo-option[aria-selected="true"]');
      if ($selectedOption.length) $selectedOption.focus();
      else $comboOptions.first().focus();
    }

    // Handle input field events
    $comboInput.on('input', function () {
      const query = $comboInput.val().toLowerCase();

      // Show or hide dropdown based on input length (minimum of 2 characters)
      if (query.length >= 2) {
        let matchFound = false;

        // Iterate over all options to toggle visibility based on the query
        $comboOptions.each(function () {
          const $option = $(this);
          if ($option.is($noItemsOption)) { // Prevent searching the query in empty item option
            return;
          }
          const optionText = $option.text().toLowerCase();

          // Show or hide options based on whether they match the query
          if (optionText.includes(query)) {
            $option.show(); // Show the option if it matches
            matchFound = true;
          } else {
            $option.hide(); // Hide the option if it doesn't match
          }
        });

        // If no matches found, show "No items available" as an option inside the list
        if (!matchFound) {
          $comboMenu.children().hide();
          $noItemsOption.show();
          $headCell.hide();
        } else {
          // If matches are found, hide the "No items available" message, if present
          $noItemsOption.hide();
          $headCell.show();
        }

        // Toggle dropdown visibility
        toggleDropdown(true);

      } else {
        // If less than 2 characters, hide dropdown
        toggleDropdown(false);
      }

      // Show or hide the clear icon based on input value
      $clearIcon.toggle(query.length > 0);
    });

    // Handle keydown events on input field
    $comboInput.on('keydown', (e) => {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        toggleDropdown(true);
      }
    });

    // Handle keydown events on options
    $comboMenu.on('keydown', '.combo-option', (e) => {
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        moveOptionsWithArrowKeys(e);
      } else if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        selectOption($(e.target));
      }
    });

    // Close dropdown on ESC key
    $(document).on('keydown', (e) => {
      if (e.key === 'Escape') toggleDropdown(false);
    });

    // Close dropdown on outside click
    $(document).on('click', closeDropdownOnOutsideClick);

    // Handle click events on options
    // $(document).on("click",$comboOptions,function() {
    //   selectOption($(this));
    //  });

    $comboMenu.on('click', '.combo-option', (e) => {
      selectOption($(e.target));
    });


    // Handle click event for the clear icon to reset input field
    $clearIcon.on('click', function () {
      $comboInput.val('');
      $comboOptions.show();  // Show all options again
      toggleDropdown(false);  // Close dropdown
      $comboInput.focus();    // Focus on input
      $clearIcon.hide();      // Hide the clear icon
    });

    // Handle keydown events on the clear icon
    $clearIcon.on('keydown', function (e) {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault(); // Prevent default action for Enter and Space
        $comboInput.val(''); // Clear the input value
        $comboOptions.show();  // Show all options again
        toggleDropdown(false);  // Close the dropdown
        $comboInput.focus();    // Focus on the input field
        $clearIcon.hide();      // Hide the clear icon
      }
    });

    // Ensure the dropdown is initially hidden and clear icon is hidden
    toggleDropdown(false);
    $clearIcon.hide();
  });
}

function initializeSelectTable(row) {
  $(row).find('select').each(function (index) {
    $(this).addClass(`select2-row-${index}`);
    $(this).select2({
      width: '100%',
      minimumResultsForSearch: -1,
    }); // Initialize Select2 for this row's select elements
  });
}

// Function to initialize Select2 for all select elements with the class 'otherSelect'
function initializeSelect2() {
  $('.otherSelect').each(function (index) {
    $(this).addClass(`select2-row-${index}`);
    $(this).select2({
      width: '100%',
      minimumResultsForSearch: -1,
    }); // Initialize Select2
  });
}


let tblPaginateAddTimeOut = {}; // For storing the timeout id
var $filterRows = {}; // For storing filter rows of tables
function tblPaginateDrawCallback() {

  $(this).parent().append($(".custom_pagination_rowselector"));
  $(".custom_pagination_rowselector select").select2({
    theme: "default",
    minimumResultsForSearch: Infinity
  });

  const $this = $(this);
  const currentTable = this.api().table(); // Get current table instance where the callback is invoked
  const currentTableId = $this.attr('id');
  const pageInfo = currentTable.page.info();
  const totalPages = pageInfo.pages;

  // Make the filterRow to stay at top
  if ($this.hasClass('filterTable')) {
    if (!currentTableId) throw new Error('Table Id not defined. Please add id attribute to <table>, for filtering rows!');
    // If table's filter row is not in $filterRows array, add it to array
    if (currentTableId && !$filterRows[currentTableId]) {
      $filterRows[currentTableId] = $this.find('.filterRow').first(); // Get filterRow and add to array
      // Add event listener to the table to run at the end of each draw event
      currentTable.on('draw.dt', function () {
        $filterRows[currentTableId].insertBefore($this.find(`tbody tr:nth-child(1)`)); // Move filterRow above first table row
      })
    }
    // To hide filterRow if there are no results for searched value
    if ($filterRows[currentTableId]) {
      if (pageInfo.recordsDisplay === 0) $filterRows[currentTableId].hide();
      else $filterRows[currentTableId].show();
    };
  }

  if (!currentTableId) console.error('Table Id not defined. Please add id attribute to <table> to fix paginateInput a11y issue!');
  // Create input element jquery object
  const $paginationInput = $('<input>', {
    class: 'paginateInput form-control',
    type: 'number',
    min: 1,
    max: pageInfo.pages,
    id: `${currentTableId ? currentTableId : "noTableId"}_paginateInput`,
  }).val(pageInfo.page + 1).attr('aria-label', `Current page ${pageInfo.page + 1} of ${totalPages}, enter a new page number to navigate`); // Aria label for a11y

  // Create pagination container along with total page count element
  const $paginationStatsContainer = $('<div>', {
    class: 'paginationStatsCont'
  }).append(
    $paginationInput,  // Append the pagination input
    $('<div>', { class: 'count' })
      .text('of')
      .append($('<strong>', { class: 'total' }).text(totalPages)) // Append the "of totalPages"
  );

  const pagingCol = currentTable.container().querySelector('.pagingCol'); // Get pagingCol element from current table instance
  const paginateInputEl = pagingCol.querySelector(".paginateInput"); // Get paginate input element

  // Function to insert the page number input after the "Previous" button
  function appendPaginationStats() {
    if (pagingCol && !paginateInputEl) {
      const $pagingNav = $(pagingCol).find("nav"); // Get <nav> element since all the buttons are added to it by DataTable
      if (!currentTableId) throw new Error('Table Id not defined. Please add id attribute to <table> for table pagination!');
      // Check if any previous timeout is pending and clear them to prevent unnecessary additions
      if (tblPaginateAddTimeOut[currentTableId]) {
        clearTimeout(tblPaginateAddTimeOut[currentTableId]);
      }
      // Append the pagination stats container after "Previous" button; setTimeout is used here to make sure "Previous" button is available in the DOM
      tblPaginateAddTimeOut[currentTableId] = setTimeout(() => {
        if ($pagingNav.children(".previous")) {
          $paginationStatsContainer.insertAfter($pagingNav.children(".previous"));
        }
      }, 0);
      $pagingNav.attr('aria-label', `pagination for ${currentTableId}`); // Add tableId to the 
    } else if (pagingCol && paginateInputEl) {
      $(paginateInputEl).val(pageInfo.page + 1); // If element already exists, update the current page value
    }
  }

  appendPaginationStats(); // Initialize function to append pagination stats
  currentTable.on("column-sizing.dt", appendPaginationStats); // Invoke the append function when current table columns are resized either by resposiveness or window.resize event

  if ($paginationInput.length) {
    $paginationInput.val(pageInfo.page + 1); // Set current page in the input
    $paginationInput[0].addEventListener('change', function () {
      const $this = $(this);
      // Check if input value is empty or not a number
      if ($this.val() === '' || $this.val().match(/[^0-9]/)) {
        /* Nothing entered or non-numeric character */
        $this.val(currentTable.page.info().page + 1) // If input value is not within limits, change it to current page number
          .attr('aria-label', `Current page ${currentTable.page.info().page + 1} of ${totalPages}, enter a new page number to navigate`);
        return;
      }

      const pageInputVal = parseInt(this.value, 10);
      if (pageInputVal >= 1 && pageInputVal <= totalPages) {
        currentTable.page(pageInputVal - 1).draw('page'); // Draw the table if entered value is within limit
      } else {
        $this.val(currentTable.page.info().page + 1) // If input value is not within limits, change it to current page number
          .attr('aria-label', `Current page ${currentTable.page.info().page + 1} of ${totalPages}, enter a new page number to navigate`);
      }
    });
  }
  initializeSelect2();

}

function stepper() {
  const currentUrl = window.location.pathname.split("/").pop();
  $('.stepper li').each(function (index) {
    if ($(this).data('url') + '.html' === currentUrl) {
      $(this).addClass('active')
      $(this).prevAll('li').addClass('visited')
      $(this).nextAll('li').removeClass('visited active')
      $('.stepNumber').text(index + 1)
      $('.activeStepName').text($(this).find('span:nth-child(2)').text())
      if ($(this).parents('.exportSteps').length || $(this).parents('.reportSteps').length) {
        $('li.breadcrumb-item.active').text($(this).find('span:nth-child(2)').text())
      }
    }

    $(this).click(function () {
      if ($(this).hasClass('visited')) {
        window.location.replace($(this).data('url') + '.html')
      }
    })
  })
}

function inputPassword() {
  $("#eyePassword").on('click', function (event) {
    event.preventDefault();
    if ($('.PasswordCol input').attr("type") == "text") {
      $('.PasswordCol input').attr('type', 'password');
      $('.PasswordCol .input-group i').addClass("fa-eye-slash");
      $('.PasswordCol .input-group i').removeClass("fa-eye");
    } else if ($('.PasswordCol input').attr("type") == "password") {
      $('.PasswordCol input').attr('type', 'text');
      $('.PasswordCol .input-group i').removeClass("fa-eye-slash");
      $('.PasswordCol .input-group i').addClass("fa-eye");
    }
  });
}
function initializeSelect2ForResponsive() {
  // Check window width
  if (window.innerWidth < 1250) {
    $(".customSelect").each(function () {
      const parent = $('body');
      $(this).select2({
        theme: "default",
        dropdownParent: parent,
        width: '100%'
      });
    })
  } else {
    $(".customSelect").each(function () {
      const parent = $(this).parent('.form-group').length ? $(this).parent('.form-group') : $('body');
      $(this).select2({
        theme: "default",
        dropdownParent: parent,
        width: '100%'
      });
    })
  }
}

const handleTabScrollLeftRight = () => {
  const navWrapper = document.querySelector('.nav-wrapper');
  const scrollLeftBtn = document.getElementById('scrollLeftBtn');
  const scrollRightBtn = document.getElementById('scrollRightBtn');

  if (navWrapper && scrollLeftBtn && scrollRightBtn) {
    // Scroll left function
    scrollLeftBtn.addEventListener('click', () => {
      navWrapper.scrollBy({
        left: -200, // Scroll left by 200px
        behavior: 'smooth',
      });
    });

    // Scroll right function
    scrollRightBtn.addEventListener('click', () => {
      navWrapper.scrollBy({
        left: 200, // Scroll right by 200px
        behavior: 'smooth',
      });
    });

    // Show/Hide buttons based on scroll position
    function toggleScrollButtons() {
      scrollLeftBtn.style.display = navWrapper.scrollLeft > 0 ? 'block' : 'none';
      scrollRightBtn.style.display =
        navWrapper.scrollLeft + navWrapper.clientWidth < navWrapper.scrollWidth
          ? 'block'
          : 'none';
    }

    // Event listener for scrolling
    navWrapper.addEventListener('scroll', toggleScrollButtons);
    window.addEventListener('resize', toggleScrollButtons);

    // Initial toggle on load
    toggleScrollButtons();
  }
}

function customFileUploader() {
  document.querySelectorAll(".drop-zone__input").forEach((inputElement) => {
    const dropZoneElement = inputElement.closest(".drop-zone");
    // Use a unique ID to avoid conflicts
    const fileListId = `fileList-${Math.random().toString(36).slice(2)}`;
    let fileListContainer = document.getElementById(fileListId) || createFileListContainer(dropZoneElement, fileListId);
    const existingFiles = new Set();

    // Click handler
    dropZoneElement.addEventListener("click", (e) => {
      if (!e.target.closest('.remove-file')) {
        console.log("Drop zone clicked, opening file explorer");
        inputElement.click();
      }
    });

    // Change handler
    inputElement.addEventListener("change", (e) => {
      console.log("Change event fired, files:", inputElement.files);
      if (inputElement.files.length) {
        // Re-verify fileListContainer before adding files
        fileListContainer = document.getElementById(fileListId) || createFileListContainer(dropZoneElement, fileListId);
        Array.from(inputElement.files).forEach(file => {
          if (!existingFiles.has(file.name)) {
            console.log(`Adding file: ${file.name}`);
            existingFiles.add(file.name);
            addFileToList(file, fileListContainer);
          } else {
            console.log(`Duplicate file skipped: ${file.name}`);
          }
        });
        inputElement.value = '';
        console.log("File input reset");
      } else {
        console.log("No files selected");
      }
    });

    // Drag-and-drop handlers
    dropZoneElement.addEventListener("dragover", (e) => {
      e.preventDefault();
      dropZoneElement.classList.add("drop-zone--over");
    });

    ["dragleave", "dragend"].forEach((type) => {
      dropZoneElement.addEventListener(type, () => {
        dropZoneElement.classList.remove("drop-zone--over");
      });
    });

    dropZoneElement.addEventListener("drop", (e) => {
      e.preventDefault();
      dropZoneElement.classList.remove("drop-zone--over");
      console.log("Drop event fired, files:", e.dataTransfer.files);
      if (e.dataTransfer.files.length) {
        // Re-verify fileListContainer
        fileListContainer = document.getElementById(fileListId) || createFileListContainer(dropZoneElement, fileListId);
        inputElement.files = e.dataTransfer.files;
        Array.from(e.dataTransfer.files).forEach(file => {
          if (!existingFiles.has(file.name)) {
            console.log(`Adding dropped file: ${file.name}`);
            existingFiles.add(file.name);
            addFileToList(file, fileListContainer);
          } else {
            console.log(`Duplicate dropped file skipped: ${file.name}`);
          }
        });
        inputElement.value = '';
        console.log("File input reset after drop");
      }
    });

    function createFileListContainer(dropZoneElement, id) {
      const container = document.createElement("div");
      container.id = id;
      container.innerHTML = `<div class="fileList"><ul></ul></div>`;
      dropZoneElement.parentNode.insertBefore(container, dropZoneElement.nextSibling);
      console.log(`File list container created with ID: ${id}`);
      return container;
    }

    function addFileToList(file, container) {
      const ul = container.querySelector("ul");
      if (!ul) {
        console.error("Error: <ul> not found in fileListContainer. Re-creating container.");
        container.innerHTML = `<div class="fileList"><ul></ul></div>`;
        return addFileToList(file, container); // Retry with new <ul>
      }

      const li = document.createElement("li");
      li.className = "ng-star-inserted";

      const fileInfo = document.createElement("div");
      fileInfo.className = "start completed";

      const statusIcon = document.createElement("i");
      statusIcon.className = "fa-regular fa-check";

      const infoText = document.createTextNode(` ${file.name} (${formatFileSize(file.size)}) `);

      const removeBtn = document.createElement("button");
      removeBtn.className = "remove-file";
      removeBtn.innerHTML = '<i class="fa-regular fa-xmark"></i>';

      const endDiv = document.createElement("div");
      endDiv.className = "end";
      endDiv.appendChild(removeBtn);

      fileInfo.appendChild(statusIcon);
      fileInfo.appendChild(infoText);
      li.appendChild(fileInfo);
      li.appendChild(endDiv);
      ul.appendChild(li);
      console.log(`File added to list: ${file.name}`);

      removeBtn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        li.remove();
        existingFiles.delete(file.name);
        console.log(`File removed: ${file.name}`);
      });
    }

    function formatFileSize(bytes) {
      if (bytes === 0) return "0 Bytes";
      const k = 1024;
      const sizes = ["Bytes", "KB", "MB", "GB"];
      const i = Math.floor(Math.log(bytes) / Math.log(k));
      return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
    }
  });
}

function galleryFn() {
  let imgPath;
  $(".insertBtn.insertImage").click(function () {
    imgPath = $('.thumbnailImage.active img').attr('src');
    if (imgPath) {
      const dropzoneContainer = ":not(.modal) .drop-zone.chooseImage";
      if (!$(dropzoneContainer).hasClass('imgSelected')) {
        $(`${dropzoneContainer} :not(.drop-zone__input)`).hide();
        const innerImage = `<div class='chooseFileInner h-100 d-flex flex-column align-items-center justify-content-center'>
                      <img src="${imgPath}" alt=""/>
                      <p class="mb-0 mt-2 uploadhints">Choose another image or change image</p>
                    </div>`;
        $(dropzoneContainer).append(innerImage);
        $(dropzoneContainer).addClass('imgSelected');
        $(dropzoneContainer).css('height', '264px');
      }
    }

    $(".uploadicon").hide();
    $(".chooseFileInner").show();
    $('.chooseFileInner img').attr('src', imgPath);
    $("#uploadFilesPopup").modal('toggle');
  })

  $(".listMode").click(function () {
    $(this).closest('.tab-pane').find('.tabularSec').first().addClass('p-0');
    $(this).closest('.tab-pane').find('.table-responsive-lg').first().removeClass('p-3');
    $('.viewMode').removeClass('active');
    $(this).addClass('active');
    $('.imagesGrid').removeClass('gridView');
    $('.imagesGrid').addClass('listView');
    $('.imagesGrid .thumbnailImage').matchHeight();
  });

  $(".gridMode").click(function () {
    $(this).closest('.tab-pane').find('.tabularSec').first().removeClass('p-0');
    $(this).closest('.tab-pane').find('.table-responsive-lg').first().addClass('p-3');
    $('.viewMode').removeClass('active');
    $(this).addClass('active');
    $('.imagesGrid').removeClass('listView');
    $('.imagesGrid').addClass('gridView');
    $('.imagesGrid .thumbnailImage').matchHeight();
  });

  $(".modal .imagesGrid li .imgCard").click(function () {
    $(".imagesGrid li .thumbnailImage").removeClass('active');
    $(this).find('.thumbnailImage').addClass('active');
    imgPath = $(this).find('.thumbnailImage img').attr('src');
  })
  $(".modal .imagesGrid li .imgCard").keyup(function () {
    $(".imagesGrid li .thumbnailImage").removeClass('active');
    $(this).find('.thumbnailImage').addClass('active');
    imgPath = $(this).find('.thumbnailImage img').attr('src');
  });

  $(document).on("click", ".tabularSec .imagesGrid:not(.bulkGrid) li .imgCard", function () {
    $(".imagesGrid li .thumbnailImage").removeClass('active');
    $(this).find('.thumbnailImage').addClass('active');
    // imgPath = $(this).find('.thumbnailImage img').attr('src');
    // $("#uploadFilesDetailsPopup").modal('show');
    $(".uploadFilterBox").hide();
    $(".uploadOptionBox").css('display', 'flex');
  })

  $('.bulkSelect').click(function () {
    $('.imagesGrid').addClass('bulkGrid');
  })
  $(document).on("click", ".tabularSec .imagesGrid.bulkGrid li .imgCard", function () {
    if ($(this).find('.thumbnailImage').hasClass("active")) {
      $(this).find('.thumbnailImage').removeClass('active');
    } else {
      $(this).find('.thumbnailImage').addClass('active');
    }

  })

  $(document).mouseup(function (e) {
    var container = $(".tabularSec .imagesGrid li .imgCard");

    // if the target of the click isn't the container nor a descendant of the container
    if (!container.is(e.target) && container.has(e.target).length === 0) {
      if (!$(e.target).hasClass('insertBtn')) $('.imagesGrid:not(.bulkGrid) .thumbnailImage').removeClass('active');
      $(".uploadFilterBox").css('display', 'flex');
      $(".uploadOptionBox").hide();
      // $('.imagesGrid').removeClass('bulkGrid');
    }
  });
}

function tableAllSelectFn() {
  // Handle select all check box
  $(document).on("click", ".allClick", function () {
    const isChecked = $(this).prop("checked"); // get current checked status
    $(this).closest(".tableOuter").find("input[type='checkbox']:not(.allClick)").each(function () {
      $(this).prop('checked', isChecked); // update all checkbox checked status except triggered checkbox
      $(this).siblings('label').first().attr("aria-checked", isChecked); // update aria-checked
    })
  })

  // To make select all checkbox to be checked or unchecked according to the state of all the row checkboxes
  $(".tableOuter input[type='checkbox']:not(.allClick)").on("click", function () {
    const $checkboxes = $(this).closest(".tableOuter").find("input[type='checkbox']:not(.allClick)");
    let checkedCount = 0;
    $checkboxes.each(function () {
      if ($(this).prop("checked")) checkedCount++;
    });
    const $selectAllCheckbox = $(this).closest(".tableOuter").find("input[type='checkbox'].allClick").first();
    if (checkedCount === $checkboxes.length) {
      $selectAllCheckbox.prop("checked", true);
      $selectAllCheckbox.next("label").attr("aria-checked", true);
    } else {
      $selectAllCheckbox.prop("checked", false);
      $selectAllCheckbox.next("label").attr("aria-checked", false);
    };
  })
}

function utilityFunction() {
  $('.modal').on('shown.bs.modal', function () {
    $($.fn.dataTable.tables(true)).DataTable().columns.adjust();
  });

  $('[data-bs-toggle="tab"]').on('shown.bs.tab', function () {
    $($.fn.dataTable.tables(true)).DataTable().columns.adjust();
  });

  $('.accordion').on('shown.bs.collapse', function () {
    $($.fn.dataTable.tables(true)).DataTable().columns.adjust();
  });

  $('.profileSection a').removeClass('active');
  $('.closemobNavigation').click(function () {
    $('.navbar-toggler').addClass('collapsed')
    // $('.appLeftMenu').removeClass('slide-opened');
    $('.appLeftMenu').hide("slide", { direction: "left" }, 600, function () {
      $('.navbar a:first').focus();
    });
    $('.profileSection a').removeClass('active');
    $('body').removeClass('overflow-hidden');
  })
  $('.magnifySearch').click(function () {
    // Toggle the search column with a sliding animation
    $(".SearchCol").slideToggle(500, "easeInOutCirc", function () {
      // After the slide animation completes, set focus to the input field
      $('.SearchCol input').focus();
    });
  });

  // Handle the Tab key inside the input field to move focus to the notification <li> and slide up the SearchCol
  $('.SearchCol input').on('keydown', function (e) {
    // Check if the Tab key is pressed
    if (e.key === "Tab") {
      e.preventDefault(); // Prevent the default Tab behavior

      // Find the <li> element containing .notificationIcon and set focus to it
      var notificationLi = $('.notificationIcon'); // Assuming the notificationIcon is inside an <li>

      if (notificationLi.length) {
        // Slide up the SearchCol
        $(".SearchCol").slideUp(500, "easeInOutCirc");

        // After sliding up, focus on the notification <li>
        notificationLi.focus();
      }
    }
  });


  $('[data-bs-toggle="tooltip"]').each(function () {
    $(this).tooltip({ container: 'body' })
  });

  setTimeout(() => {
    const tooltipElements = document.querySelectorAll('.sideIcon');
    tooltipElements.forEach((tooltipTriggerEl) => {
      new bootstrap.Tooltip(tooltipTriggerEl, {
        container: 'body',
        customClass: 'menuTooltip'
      });
    });
  }, 100);

  $('.maincollapseBtn').click(function () {
    // Trigger the button's click to handle collapse
    $(this).children('button')[0].click();

    // Check the current state of the button and toggle 'open' class accordingly
    if ($(this).children('button').hasClass('collapsed')) {
      $(this).closest('.accordion-header').removeClass('open');
    } else {
      $(this).closest('.accordion-header').addClass('open');
    }
  });

  $('select.dt-input').select2({
    minimumResultsForSearch: Infinity  // Hides the search box in the dropdown
  });

  // Ensure the 'open' class is properly updated based on Bootstrap events
  $('.accordion-collapse').on('show.bs.collapse', function () {
    $(this).prev('.accordion-header').addClass('open'); // Add 'open' on expand
  });

  $('.accordion-collapse').on('hide.bs.collapse', function () {
    $(this).prev('.accordion-header').removeClass('open'); // Remove 'open' on collapse
  });
  customPopoverMenu();

  //  checkbox accessibility    
  $('input[type="checkbox"]').on('change', function () {
    const $currentCheckbox = $(this);
    const $checkboxesContainer = $currentCheckbox.closest('.form-group').first();
    const $checkboxes = $checkboxesContainer.find('input[type="checkbox"]');
    const isChecked = $currentCheckbox.prop('checked');
    const selectAllOptionValue = "All";
    const isSelectAllPresent = Array.from($checkboxes).some(checkbox => $(checkbox).val() === selectAllOptionValue);
    const labels = $checkboxes.next('label');

    // Select All checkbox functionality
    if (isSelectAllPresent) {
      // If select all checkbox is selected, update all the sibling checkboxes with it's checked state
      if ($currentCheckbox.val() === selectAllOptionValue) {
        $checkboxes.prop('checked', isChecked);
        labels.attr('aria-checked', isChecked);
        return;
      }
      // Find selected checkboxes (excluding select all) count by reduce method
      const selectedCheckboxesCount = Array.from($checkboxes).reduce((count, checkbox) => {
        if ($(checkbox).val() !== selectAllOptionValue) $(checkbox).prop('checked') ? count++ : count;
        return count;
      }, 0);
      // If selected checkboxes is equal to total checkboxes count - both exclusive of select all checkbox
      if ($checkboxes.length - 1 === selectedCheckboxesCount) {
        $checkboxes.prop('checked', true); // Update all the checkboxes with selected state
        // labels.attr('aria-checked', true);
      } else {
        const selectAllCheckbox = Array.from($checkboxes).find(checkbox => $(checkbox).val() === selectAllOptionValue)
        $(selectAllCheckbox).prop('checked', false); // Update all checkbox state with unselected state
        // $(selectAllCheckbox).next('label').attr('aria-checked', false);
      }
    }

    // $currentCheckbox.next('label').attr('aria-checked', isChecked); // Update aria-label for current checkbox
  })

  var lblCheckbox = document.querySelectorAll('input[type="checkbox"] + label');
  if (lblCheckbox.length > 0) {
    document.querySelectorAll('input[type="checkbox"] + label').forEach(item => {
      item.addEventListener('keypress', event => {
        if (event.key === ' ') {
        } else if (event.key === 'Enter') {
          var txtCheckbox = $(item).prev('input[type="checkbox"]');
          var isCheck = $(txtCheckbox).prop("checked");
          var thisval = $(txtCheckbox).next('label').text();
          if (!isCheck) {
            $(txtCheckbox).attr('checked', true);
            $(txtCheckbox).next('label').attr('aria-checked', 'true');
          } else {
            $(txtCheckbox).attr('checked', false);
            $(txtCheckbox).next('label').attr('aria-checked', 'false');
          }
        }
      })
    });
  }
  $(".customSelect").each(function () {
    const parent = $('body')
    $(this).select2({
      theme: "default",
      dropdownParent: parent,
      width: '100%'
    });
  });
  // Trigger validation on Select2 change
  $("form .customSelect, form .otherSelect").on("change", function () {
    $(this).valid();
  });
}

function customPopoverMenu() {
  const customPopoverList = document.querySelectorAll('.customPopover');
  const popoverList = [...customPopoverList].map(popoverTriggerEl =>
    new bootstrap.Popover(popoverTriggerEl, {
      trigger: 'focus',
      customClass: 'popoverModified', // Your custom class here
      placement: 'bottom',
      offset: ({ popper }) => {
        return [-popper.width / 2 + 6, 0]; // Offset position to make it vertically aligned with trigger element
      },
    })
  );
}

$(document).ajaxStop(function () {


  utilityFunction();

  $('.searchTableBox').each(function (index) {
    // Create a unique ID for each input by appending a random number or index
    var uniqueId = 'basicsearch-' + Math.random().toString(36).substr(2, 9); // Generate a random string

    // Set the unique ID to the input field inside this .searchTableBox
    $(this).find('.form-control').attr('id', uniqueId);

    // Set the unique ID to the label 'for' of input field inside .searchTableBox
    $(this).find('label').attr('for', uniqueId);

    // Get the placeholder value from data-placeholder
    var placeholderValue = $(this).data('placeholder');

    // Set the placeholder text for the input element
    if (placeholderValue) {
      $(this).find('.form-control').attr('placeholder', placeholderValue);
    } else {
      $(this).find('.form-control').attr('placeholder', 'Try searching something');
    }
  });

  if (window.location.href.indexOf('non-member-shared/') !== -1) {
    // Iterate over each link in the menu
    $('.nonMemberMenu a').each(function () {
      var link = $(this).attr('href');

      // If the link contains 'non-member-shared/', remove it
      if (link.includes('non-member-shared/')) {
        var updatedLink = link.replace('non-member-shared/', '');
        $(this).attr('href', updatedLink);
      }
    });
  }
  if (window.location.href.indexOf('documents-communications/') !== -1) {
    // Iterate over each link in the menu
    $('.nonMemberMenu a').each(function () {
      var link = $(this).attr('href');

      // If the link contains 'non-member-shared/', remove it
      if (link.includes('non-member-shared/')) {
        var updatedLink = '../' + link;
        $(this).attr('href', updatedLink);
      }
    });
  }
  // Check if the current URL contains '/fleet/' or '/authentication/'
  if (window.location.href.indexOf('/fleet/') !== -1 || window.location.href.indexOf('/authentication/') !== -1) {
    // Iterate over each link in the menu
    $('.nonMemberMenu a').each(function () {
      var link = $(this).attr('href');

      // Prepend '../non-member-shared/' to the link
      if (!link.includes('http')) { // Ensure it's a relative URL
        var updatedLink = '../' + link;
        $(this).attr('href', updatedLink);
      }
    });
  }

  $('.headeritems a').hide(); $('.headeritems span').hide();
  if (window.location.href.indexOf('shared-client-admin-deltaplus') !== -1) {
    $('.headeritems .selectHomeItems').show();
  } else if (window.location.href.indexOf('shared-client-admin-fleet') !== -1) {
    $('.headeritems .selectHomeItems').show();
  } else if (window.location.href.indexOf('member-benefits-') !== -1) {
    $('.headeritems a').show(); $('.headeritems span').show();
    $('.headeritems .selectHomeItems').hide();
  }

  // On click of .selectMember
  $('.selectMember').on('click', function (e) {
    e.preventDefault(); // Prevent the default navigation temporarily

    // Set the session storage value to true
    sessionStorage.setItem('selectedMember', 'true');

    // Redirect to the specified page after setting the session data
    const targetUrl = $(this).attr('href');
    window.location.href = targetUrl; // Navigate to the target page
  });

  $('.selectComp').on('click', function (e) {
    $('.selectCompany').hide();
    $('.lblCompany, .cmpChange').show();
  });

  // Check if session storage has the 'selectedMember' value
  if (sessionStorage.getItem('selectedMember') === 'true') {
    // Run these actions if session storage is set
    $('.headeritems a').show();
    $('.headeritems span').show();
    $('.headeritems .selectHomeItems').hide();
  }


  $(window).resize(function () {

    // Destroy the current instance and reinitialize based on window size
    $('.customSelect').select2('destroy');
    initializeSelect2ForResponsive();
  });
  $(document).on('select2:open', function (e) {
    window.setTimeout(function () {
      document.querySelector('input.select2-search__field').focus();
    }, 0);
  });

  $('.addtoFav').click(function () {
    var $this = $(this);
    if ($this.hasClass('activeFav')) {
      $this.attr('data-bs-original-title', 'Add to favorites');
      $this.attr('aria-label', 'Add to favorites');
    } else {
      $this.attr('data-bs-original-title', 'Remove from favorites');
      $this.attr('aria-label', 'Remove from favorites');
    }
    $this.toggleClass('activeFav');
  });

});


function handleTableCheckbox(className) {
  // Initially hide the `bulkDropdown` div
  $(`.${className}`).hide();
  $(document).on("change", "input[name='bulkcheckall']", function () {
    const isChecked = $(this).prop("checked");
    if (isChecked) {
      $(`.${className}`).show();
    } else {
      $(`.${className}`).hide();
    }
    $(this).closest(".tableOuter").find("input[type='checkbox']:not([name='bulkcheckall'])").each(function () {
      $(this).prop("checked", isChecked);
      $(this).siblings('label').first().attr("aria-checked", isChecked);
    });
  });
  $(".tableOuter input[type='checkbox']:not([name='bulkcheckall'])").on("click", function () {
    const $checkboxes = $(this).closest(".tableOuter").find("input[type='checkbox']:not([name='bulkcheckall'])");
    const checkedCount = $checkboxes.filter(":checked").length;
    const $selectAllCheckbox = $(this).closest(".tableOuter").find("input[name='bulkcheckall']").first();
    if (checkedCount > 0) {
      $(`.${className}`).show();
    } else {
      $(`.${className}`).hide();
    }
    if (checkedCount === $checkboxes.length) {
      $selectAllCheckbox.prop("checked", true);
      $selectAllCheckbox.next("label").attr("aria-checked", true);
    } else {
      $selectAllCheckbox.prop("checked", false);
      $selectAllCheckbox.next("label").attr("aria-checked", false);
    }
  });
}



function adjustFixedColumnsResponsive(dataTableInstance, dataTableOptions) {
  if (!dataTableInstance) return console.error("Error! Pass in valid dataTableInstance or move the table instance variable to global scope, for adjusting fixed columns responsiveness!")
  const $currentTable = $(dataTableInstance?.settings()[0]?.nTable);
  if (!$currentTable) return; // Return if such datatable instance doesn't exist
  // Function to adjust fixedColumns based on screen width
  function adjustFixedColumns() {
    const screenWidth = window.innerWidth;
    if ($currentTable.closest('.tableOuter').find('.dtfc-top-blocker, .dtfc-bottom-blocker').length > 0) {
      if (screenWidth < 1200) {
        // Reset fixed columns config values to 0
        dataTableInstance.fixedColumns().left(0).right(0);
        // Enable custom scrollbar

      } else {
        // Restore the original config values from datatTableOptions
        dataTableInstance.fixedColumns().left(dataTableOptions.fixedColumns?.start).right(dataTableOptions.fixedColumns?.end);
        // Destroy custom scrollbar to avoid conflict with fixed scroll
        $(dataTableInstance).parent().mCustomScrollbar("destroy");
      }
    }
  }
  // Trigger the adjustment when the window is resized
  window.addEventListener('resize', adjustFixedColumns);
  // Initial adjustment on page load
  adjustFixedColumns();
}

function initCalendar() {
  $(".datepicker").each(function () {
    // if(!$(this).daterangepicker('destroy'))
    $(this).daterangepicker({
      singleDatePicker: true,
      autoUpdateInput: false,
      showDropdowns: true,
      autoApply: true,
      locale: {
        cancelLabel: 'Clear',
        format: 'MM/DD/YYYY'
      }
    });
  });
  $(".datepicker-range").daterangepicker({
    opens: 'left',
    autoUpdateInput: false,
    autoApply: true,
    locale: {
      cancelLabel: 'Clear'
    }
  });
  $('.datepicker').each(function () {
    $(this).on('apply.daterangepicker', function (ev, picker) {
      $(this).val(picker.startDate.format('MM/DD/YYYY'))
    });
  })

  $('.datepicker-time').each(function () {
    $(this).daterangepicker({
      autoUpdateInput: false,
      singleDatePicker: true,
      timePicker: true,
      timePickerSeconds: true,
      showDropdowns: true,
      locale: {
        format: 'DD/MM/YYYY h:mm:ss A',
        cancelLabel: 'Clear',
      }
    });
    $('.datepicker-time').on('apply.daterangepicker', function (ev, picker) {
      $(this).val(picker.startDate.format('DD/MM/YYYY h:mm:ss A'))
    });
  })

}

let editors = {};
let editorPromises = {}; // Store promises for each editor

function initTextEditor(id) {
  const textarea = document.querySelector(`#${id}`);
  if (!textarea) return;

  const config = id === "templateEditorsms"
    ? { toolbar: [], placeholder: "Select a Template Variable..." }  // No toolbar for templateEditor
    : {}; // Default CKEditor config for others

  editorPromises[id] = ClassicEditor.create(textarea, config)
    .then(editor => {
      editors[id] = editor;
      editor.ui.view.editable.element.style.minHeight = "225px";

      // Set character limit check (160 chars)
      const charLimit = 160;
      const errorMsg = document.createElement("div");
      errorMsg.style.color = "red";
      errorMsg.style.fontSize = "12px";
      errorMsg.style.display = "none";
      errorMsg.textContent = `Character limit of ${charLimit} exceeded!`;
      textarea.parentNode.appendChild(errorMsg);

      editor.model.document.on("change:data", () => {
        const content = editor.getData().replace(/<[^>]*>/g, ""); // Remove HTML tags
        errorMsg.style.display = content.length > charLimit ? "block" : "none";
      });

      if (id === "templateEditorsms") {
        // Create wrapper div with class "mb-2"
        const dropdownWrapper = document.createElement("div");
        dropdownWrapper.classList.add("mb-2");

        // Create select element with class "form-select"
        const dropdown = document.createElement("select");
        dropdown.classList.add("form-control");
        dropdown.innerHTML = `
          <option value="">Select a Template Variable</option>
          <option value="{name}">{name}</option>
          <option value="{email}">{email}</option>
          <option value="{date}">{date}</option>
        `;

        // Append select to wrapper
        dropdownWrapper.appendChild(dropdown);

        // Insert dropdown wrapper before the textarea
        textarea.parentNode.insertBefore(dropdownWrapper, textarea);

        // Handle variable insertion in CKEditor
        dropdown.addEventListener("change", () => {
          const selectedValue = dropdown.value;
          if (selectedValue) {
            editor.model.change(writer => {
              const insertPosition = editor.model.document.selection.getFirstPosition();
              writer.insertText(selectedValue, insertPosition);
            });
          }
        });
      }


      return editor;
    })
    .catch(error => {
      console.error(`Error initializing CKEditor for ${id}:`, error);
    });
}





function addContent(editorId, editorContent) {
  if (editors[editorId]) {
    editors[editorId].setData(editorContent);
  } else if (editorPromises[editorId]) {
    editorPromises[editorId].then(editor => {
      editor.setData(editorContent);
    });
  } else {
    console.log(`Editor ${editorId} has not been initialized.`);
  }
}


function formBuilder() {
  $.getJSON("data/data.json", function (data) {
    // Loop through each section in the JSON data
    $.each(data.sections, function (sectionIndex, section) {
      // Check if a section with the same ID exists in the HTML
      const sectionId = section.sectionName;
      const sectionElement = $(`[data-form-section='${sectionId}']`);
      sectionElement.attr('id', `form_${section.sectionName}`)
      const editMode = section.edit ? true : false;
      const formRow = document.createElement('div')
      formRow.classList.add('formRow')
      if (section.customFormRowClass) {
        formRow.classList.add(section.customFormRowClass);
      }

      if (editMode) {
        formRow.classList.add('editMode')
      }

      var rulesObj = {}
      var messageObj = {}

      sectionElement.prepend(formRow)

      // Loop through the labels of the current section
      $.each(section.labels, function (labelIndex, item) {

        const labelId = `${sectionId}_${labelIndex}`;

        if (item.required) {
          Object.assign(rulesObj, {
            [labelId]: { required: true }
          });
          Object.assign(messageObj, {
            [labelId]: { required: `${item.label} is required` }
          });
        }

        let label = `<label for="${labelId}">${item.required ? '<strong class="mndtry" aria-hidden="true">*</strong><span class="mndtry-txt sr-only">required</span>' : ''}${item.label}</label>`

        if (item.tooltip) {
          label += ` <a href="javascript:void(0)" class="customTooltip" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="${item.tooltipContent}" data-bs-original-title="" title=""><span class="visually-hidden">Info</span> <i class="fa-regular fa-circle-exclamation" aria-hidden="true"></i></a>`
        }

        // if (item.required) {
        //   label = label + `<span class="sr-only">required</span>`
        // }

        // Create input field based on item properties (dropdown, datepicker, etc.)
        let inputField = '';

        if (item.isDropdown) {
          // If dropdown is true, create a select dropdown
          let optionsHtml = '';
          let curOption = item.inputValue;

          $.each(item.options, function (index, option) {
            // Check if the option matches the inputValue and set it as selected
            const isSelected = option === item.inputValue ? 'selected' : '';

            if (isSelected.length > 0) {
              curOption = option;
            }

            optionsHtml += `<option value="${option}" ${isSelected}>${option}</option>`;
          });

          inputField = ` <select class="${item.noEdit ? 'd-none' : 'form-select otherSelect formEdit'}" ${item.disabled ? 'disabled' : ''} id="${labelId}"  data-name="${item.customName ? item.customName : ''}">
                  ${optionsHtml}
                </select>
                <span class="${item.noEdit ? '' : 'formView'}">${curOption}</span>`

        }
        else if (item.isDatePicker) {
          // If it's a date picker, add the 'datepicker' class to input
          inputField =
            `
                            <div class="${item.noEdit ? 'd-none' : 'input-group formEdit'}">
                            <input data-name="${item.customName ? item.customName : ''}" class="form-control datepicker formEdit" type="text" id="${labelId}" name="${labelId}" value="${item.inputValue}">
                            <div class="input-group-text"><i class="fas fa-calendar-alt"></i></div>
                            </div>
                            <span data-name="${item.customName ? item.customName : ''}" class="${item.noEdit ? '' : 'formView'}">${item.inputValue}</span>
                        `
            ;
        }
        else if (item.isCheckBox) {
          inputField =
            `
                        <input type="checkbox" class="${item.noEdit ? 'd-none' : 'formEdit'}" id="${labelId}s" name="${labelId}c" ${item.inputValue.toLowerCase() === "yes" ? 'checked' : ''}>
                        <label for="${labelId}s" class="${item.noEdit ? 'd-none' : 'formEdit'}"><span class="sr-only">${item.inputValue}</span></label>
                        <span class="${item.noEdit ? '' : 'formView'}">${item.inputValue}</span>
                    `
        }
        else if (item.isRadio) {
          inputField =
            `
                        <fieldset class="${item.noEdit ? 'd-none' : 'formEdit'}">
                            <legend class="sr-only">Do you agree with the terms and conditions?</legend>
                            
                            <span class="d-inline-block me-2">
                            <input type="radio" id="${sectionId}_${labelIndex}_${item.radioValue1}" name="agreement" value="${item.radioValue1}">
                            <label for="${sectionId}_${labelIndex}_${item.radioValue1}">${item.radioValue1}</label>
                            </span>

                            <span>
                            <input type="radio" id="${sectionId}_${labelIndex}_${item.radioValue2}" name="agreement" value="${item.radioValue2}">
                            <label for="${sectionId}_${labelIndex}_${item.radioValue2}">${item.radioValue2}</label>
                            </span>
                        </fieldset>
                        <span class="${item.noEdit ? '' : 'formView'}">${item.radioValue1}</span>
                        `
        }
        else if (item.textarea) {
          // Default case, a normal text input
          inputField =
            `<textarea name="${labelId}" data-name="${item.customName ? item.customName : ''}" data-tagging="${item.taging ? true : ''}" class="${item.taging ? '' : item.noEdit ? 'd-none' : 'form-control formEdit'}" type="text" id="${labelId}" value="${item.inputValue}" ${item.textarearows ? `rows="${item.textarearows}"` : ""}>${item.inputValue}</textarea>
            <p class="${item.taging ? '' : 'd-none'} countItem">Character limit of 160</p  
            <span data-name="${item.customName ? item.customName : ''}" class="${item.noEdit ? '' : 'formView'}">${item.inputValue}</span>
                        `
        }
        else if (item.multiselect) {
          let options = ""
          let selectedOptions = ''
          item.multiSelectOptions.forEach((option, id) => {
            options += `
              <div class="checkItem">
                  <input type="checkbox" data-checkbox-id="${id}" name="Option${item.multiSelectId + id}" id="Option${item.multiSelectId + id}">
                  <label for="Option${item.multiSelectId + id}">${option}</label>
              </div>
            `
            //if(item.selectedOptions.includes(id))
            //selectedOptions+=`<span class="selected-tag" data-remove-id=${id} tabindex="0">${option}<span role="button" class="remove-tag" tabindex="0" title="remove tag"><i class="fa-regular fa-xmark"></i></span></span>`
          })
          inputField = `
                    <div class="Selectcontainer customMultiSelect w-100">
                      <div class="selected-values selectedValuesFB form-select" id="${labelId}">
                      </div>
                      <div class="dropdown-options" id="dropdownOptions${item.multiSelectId}">
                          <div class="search-box">
                              <input type="text" id="searchBox1" placeholder="Select..." aria-label="search">
                          </div>
                          ${options}
                      </div>
                  </div>
          `
        }
        else if (item.textEditor) {
          inputField = `
          <div id="${item.textEditorId}"></div>
            <span class="${item.noEdit ? '' : 'formView'}">${item.textEditorContent}</span>
          `
        }
        else if (item.uploader) {
          inputField = `
            <div class="dropzone drop-zone" id="dropzone">
              <input class="drop-zone__input" type="file" id="fileInput" multiple="" aria-label="upload file">
              <i class="fa-light fa-cloud-arrow-up"></i>
              <p>Drag &amp; drop files here </p>
              <p class="uploadhints position-relative"><span>or</span></p>
              <a href="javascript:void(0)" class="btn btn-secondary" role="button">Browse files</a>
-              <p class="${item.noHintText ? 'd-none' : ''}" class="uploadhints mb-0">Supports JPEG, JPG or PNG</p>
          </div>
            <span class="${item.noEdit ? '' : 'formView'}">${item.uploadFileDetails}</span>
          `
        }
        else if (item.searchInputDropdown) {
          inputField = `
          <div class="searchfield searchformsInput ${item.noEdit ? 'd-none' : 'formEdit'}">   
          <div class="inputWithDropdown">
              <!-- Input Field for Combobox -->
              <div class="input-group" style="position: relative;">
                  <input aria-controls="listbox1" aria-expanded="false" aria-haspopup="listbox" id="combo1" class="form-control" role="combobox" type="text" tabindex="0" aria-label="Type to search client" autocomplete="off">
                  <span class="btn" id="search_1"><i class="far fa-magnifying-glass"></i></span>
                  <span class="tbl-search-clear clearsearch-inputdrop" role="button" tabindex="0" aria-label="clear search" style="display: none;">
                      <i class="fa-solid fa-xmark"></i>
                  </span>
              </div>
              <div class="combo-menu-container"> 
                  <ul class="combo-menu" role="listbox" id="listbox1" aria-labelledby="combo1" tabindex="-1">
                      <li role="option" id="combo1-1" class="combo-option" aria-selected="false" tabindex="-1">
                          Fred
                      </li>
                      <li role="option" id="combo1-2" class="combo-option" aria-selected="false" tabindex="-1">
                          Jim
                      </li>
                      <li role="option" id="combo1-3" class="combo-option" aria-selected="false" tabindex="-1">
                          Joe
                      </li>
                      <li role="option" id="combo1-4" class="combo-option" aria-selected="false" tabindex="-1">
                          Martha
                      </li>
                      <li role="option" id="combo1-no-items" class="combo-option no-items" aria-selected="false" tabindex="-1">
                          No user found
                      </li>
                  </ul>
              </div>
          </div>
              
          </div> 
           <span class="${item.noEdit ? '' : 'formView'}">${item.inputValue}</span>
          `
        }
        else {
          // Default case, a normal text input
          inputField =
            `<input name="${labelId}" class="${item.noEdit ? 'd-none' : 'form-control formEdit'}" type="text" id="${labelId}" data-name="${item.customName ? item.customName : ''}" value="${item.inputValue}">
            ${item.link ? `<a class="${item.noEdit ? 'link' : 'formView link'} ${item.classname ? `${item.classname}` : ``}" href="javascript:void(0);">${item.inputValue}</a>` : `<span data-name="${item.customName ? item.customName : ''}" class="${item.noEdit ? '' : 'formView'}">${item.inputValue}</span>`}
            
                `
        }

        // Create the form item HTML structure
        const formItem = `
          <div class="formItem ${item.fullWidth ? ' fullWidth' : ''}${item.uploader ? ' uploadFileCol ' : ''}">
            <div class="formField${item.alignStart ? ' alignStart' : ''}">
              <div class="labelCol ${item.labelAlign == "top" ? 'alignTop' : ''}">
                ${label}
              </div>
              <div class="inputCol">
                ${inputField}
              </div>
            </div>
          </div>
        `;

        // Append the form item to the corresponding section
        sectionElement.find('.formRow').append(formItem);

        if (item.textEditor) {
          initTextEditor(item.textEditorId)
        }
        if (item.uploader) {
          customFileUploader()
        }
        if (item.taging) {
          initArrayTagging()
        }

        if (item.multiselect) {
          $(`#dropdownOptions${item.multiSelectId}`).find('.checkItem').each(function () {
            var checkItem = $(this)
            var checkId = $(this).find(`input`).attr('data-checkbox-id')
            item.selectedOptions.forEach(function (id) {
              if (checkId == id) {
                checkItem.find('input').trigger('click')
              }
            })
          })
          $('.remove-tag').click(function () {
            let checkBoxId = $(this).parents('.selected-tag').attr('data-remove-id')
            let item = $('.checkItem').find(`input[data-checkbox-id=${checkBoxId}]`)
            item.prop('checked', true)
          })

        }

      });

      if (section.validate) {
        formValidation(`form_${section.sectionName}`, rulesObj, messageObj)
      }
    });
    initializeSelect2();
    initCalendar();
  })
}

function formValidation(formid, rulesObj, messageObj, callback) {
  $(`#${formid}`).validate({
    submitHandler: function (form) {
      if ($(`#${formid}`).valid()) {
        $(`#${formid}`).find('.formRow').removeClass('editMode')
        $(`#${formid}`).find('.btnCancel,.btnSave').hide()
        $(`body`).removeClass('form-edit-mode')
        callback()
      }
      event.preventDefault();
      return false; // Prevent form submission    
    },
    rules: rulesObj,
    messages: messageObj,
    errorElement: 'p',
    errorPlacement: function (error, element) {
      error.addClass('error-text');
      let appendElement = element.closest('.formItem').length ? element.closest('.formItem').find('.inputCol') : element.closest('.form-group')
      error.appendTo(appendElement);
      applyErrorAriaDescribedby();
    }
  });
}



function redirectPage(newFileName) {
  let currentUrl = window.location.href;
  let lastSegment = currentUrl.substring(currentUrl.lastIndexOf('/') + 1);
  if (lastSegment.includes('.')) {
    let newUrl = currentUrl.replace(lastSegment, newFileName);
    window.location.href = newUrl;
  } else {
    console.error("No valid file found in URL to replace.");
  }
}

function multiSelectWithAccordionBuilder() {
  $.getJSON("data/data.json", function (data) {
    if (data.multiSelectAccItems) {
      $.each(data.multiSelectAccItems, function (multiSelectItemIndex, multiSelectItem) {
        const multiSelectId = multiSelectItem.multiSelectAccName;
        const $multiSelectContainer = $(`[data-multiselectacc-name="${multiSelectId}"]`);
        const placeholderText = multiSelectItem.placeholder ? multiSelectItem.placeholder : "Select";
        if ($multiSelectContainer.length && multiSelectItem.options) {
          $multiSelectContainer.html(generateMultiSelectWithAccordion(multiSelectItem.options, multiSelectId, placeholderText));
        }
      })
    }
  })
}




export function initArrayTagging() {
  const getToday = () => {
    const today = new Date();
    const month = String(today.getMonth() + 1).padStart(2, '0'); // MM
    const day = String(today.getDate()).padStart(2, '0'); // DD
    const year = today.getFullYear(); // YYYY
    return `${month}-${day}-${year}`;
  };

  const isEditPage = window.location.pathname.includes('edit-template-sms.html');
  const textarea = document.querySelector('textarea[data-tagging="true"]');
  const existingContent = textarea?.value.trim() || '';
  const counter = document.querySelector('p.countItem');
  const maxLength = 160;

  if (!textarea || !counter) return;

  // New static whitelist for dropdown
  const whitelist = [
    { value: 'Last Name', text: 'Last Name' },
    { value: 'First Name', text: 'First Name' },
    { value: 'Email', text: 'Email' },
    { value: 'Birth Date', text: 'Birth Date' }
  ];

  // Initialize Tagify
  const tagify = new Tagify(textarea, {
    mode: 'mix',
    pattern: /@/, // Trigger tagging with @
    tagTextProp: 'text',
    whitelist,    // Use static list
    dropdown: {
      enabled: 1,           // Show dropdown after 1 character
      position: 'text',     // Position relative to text
      highlightFirst: true, // Highlight first suggestion
      mapValueTo: 'text',   // Display 'text' in dropdown
      render: {
        suggestion: (item) => {
          // Simple dropdown item rendering
          return `<div class='tagify__dropdown__item'>
                    <strong>${item.text}</strong>
                  </div>`;
        }
      }
    },
    transformTag: (tagData) => {
      // Use the plain text as the tag
      tagData.value = tagData.text;
      tagData.text = tagData.text; // No additional formatting
    }
  });

  // Handle default tags for edit page
  if (isEditPage) {
    if (existingContent) {
      try {
        const existingTags = JSON.parse(existingContent);
        tagify.addTags(existingTags);
      } catch (e) {
        console.error("Error parsing existing tags:", e);
      }
    } else {
      const defaultTags = [{ value: 'First Name', text: 'First Name' }]; // Example default tag
      tagify.addTags(defaultTags);
      setTimeout(() => {
        const tagifyInput = textarea.parentElement.querySelector('.tagify__input');
        if (tagifyInput) {
          tagifyInput.innerHTML = '';
          tagify.value.forEach(tag => {
            const tagEl = tagify.createTagElem(tag);
            tagifyInput.appendChild(tagEl);
          });
          tagifyInput.appendChild(document.createTextNode(' this is a test message'));
          tagify.DOM.originalInput.value =
            tagify.value.map(t => t.value).join(' ') + ' this is a test message';
          tagify.update();
          updateCounter();
        }
      }, 50);
    }
  }

  const getNonTagTextLength = () => {
    const tagifyInput = textarea.parentElement.querySelector('.tagify__input');
    let fullText = '';

    tagifyInput?.childNodes.forEach(node => {
      if (node.nodeType === Node.TEXT_NODE) {
        const text = (node.textContent || '')
          .replace(/[\u00A0\u200B\s]/g, '')
          .trim();
        if (text) {
          fullText += text;
        }
      }
    });

    if (!fullText) return 0;

    const parts = fullText.split('@');
    let count = 0;

    parts.forEach((part, index) => {
      if (index === 0) {
        count += part.length;
      } else {
        const tagCount = tagifyInput.querySelectorAll('tag').length;
        const atCount = index;
        if (tagCount < atCount) {
          return;
        }
        count += part.length;
      }
    });

    return count;
  };

  const updateCounter = () => {
    const count = getNonTagTextLength();
    counter.innerHTML = count >= maxLength
      ? `Characters <strong style="color:red;">${count}/${maxLength}</strong>`
      : `Characters ${count}/${maxLength}`;
  };

  const tagifyInput = textarea.parentElement.querySelector('.tagify__input');
  tagifyInput?.addEventListener('beforeinput', (e) => {
    if (getNonTagTextLength() >= maxLength && !e.inputType?.startsWith('delete')) {
      e.preventDefault();
    }
  });

  tagify.on('input', updateCounter);
  tagify.on('add', updateCounter);
  tagify.on('remove', updateCounter);

  updateCounter();
}


// Generate Multiselect with accordion from data
function generateMultiSelectWithAccordion(selectOptions, multiSelectId, placeholderText) {
  let dropdownHtml = '';

  // Recursive function to create each level of the accordion
  function createAccordion(items, parentId) {
    let accordionHtml = '';

    $.each(items, function (index, item) {
      // Create a unique ID for each accordion section
      const currentId = `${parentId}-section-${index + 1}`;

      // Create the accordion item for the current level
      accordionHtml += `<div class="accordion-item">
                              <p class="accordion-header">
                                  <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-${currentId}" aria-expanded="false" aria-controls="collapse-${currentId}">
                                      ${item.title}
                                  </button>
                              </p>
                              <div id="collapse-${currentId}" class="accordion-collapse collapse" data-bs-parent="#${parentId}">
                                  <div class="accordion-body">`;

      // If there are further nested items, recurse, else create the checkboxes
      if (item.items && item.items.length > 0) {
        // If there are nested items, call createAccordion recursively
        accordionHtml += createAccordion(item.items, `accordion-${currentId}`);
      } else if (item.labels && item.labels.length > 0) {
        // Otherwise, create the checkbox list
        accordionHtml += '<ul class="sublist">';
        $.each(item.labels, function (labelIndex, label) {
          let isSelected = false;
          if (item.selectedLabels) {
            isSelected = item.selectedLabels.some(selectedLabel => selectedLabel === label)
          }
          const checkboxId = `option-${currentId}-${labelIndex + 1}`;
          accordionHtml += `<li>
                                      <div class="form-check ps-0">
                                          <input class="form-check-input option justone" type="checkbox" value="${label}" name="options[]" id="${checkboxId}" ${isSelected ? "checked" : ""}>
                                          <label class="form-check-label" for="${checkboxId}">
                                              ${label}
                                          </label>
                                      </div>
                                    </li>`;
        });
        accordionHtml += '</ul>';
      }

      accordionHtml += `    </div>
                              </div>
                          </div>`;
    });

    return accordionHtml;
  }

  // Generate the main dropdown structure
  dropdownHtml += `<div class="dropdown multiSelectWithAccordion">
                      <button class="form-select multiSelectBtn" type="button" data-bs-toggle="dropdown" aria-expanded="false" id="${multiSelectId}-trigger" data-bs-auto-close="outside">
                          <span class="dropdown-text">${placeholderText}</span>
                      </button>
                      <div class="dropdown-menu">
                          <div class="accordion accordion-flush" id="${multiSelectId}">`;

  // Loop through selectOptions and create the accordion items
  $.each(selectOptions, function (index, option) {
    const parentId = `${multiSelectId}-${index + 1}`;
    dropdownHtml += `<div class="accordion-item">
                          <p class="accordion-header">
                              <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-${parentId}" aria-expanded="false" aria-controls="collapse-${parentId}">
                                  ${option.title}
                              </button>
                          </p>
                          <div id="collapse-${parentId}" class="accordion-collapse collapse" data-bs-parent="#${multiSelectId}">
                              <div class="accordion-body">`;

    // Recursively generate the nested content for this option
    dropdownHtml += createAccordion(option.items, `accordion-${parentId}`);

    dropdownHtml += `    </div>
                        </div>
                      </div>`;
  });

  // Close the main accordion and dropdown structure
  dropdownHtml += `        </div>
                  </div>
              </div>`;

  // Initialize the dropdown and accordion behavior
  const dropdownElement = $(dropdownHtml);

  // Create the tag container that will hold the selected tags outside of the dropdown menu
  const selectedTagsContainer = $(`<div class="selected-tags d-none"></div>`);
  const multiSelectBtn = dropdownElement.find('.multiSelectBtn');
  multiSelectBtn.append(selectedTagsContainer); // Place it after the button

  // Function to created selected label tags and append to dropdown element trigger button 
  function showSelectedLabels($checkInput) {
    const label = $checkInput.next('label').text().trim();
    const parentAccTitle = $checkInput.closest('.accordion-item').find('.accordion-button').first().text().trim();
    const grandParentAccTitle = $checkInput.closest('.accordion-item').parent().closest('.accordion-item').find('.accordion-button').first().text().trim();
    const accParents = grandParentAccTitle ? `${grandParentAccTitle}___${parentAccTitle}` : parentAccTitle;

    // When checkbox is checked, create a new tag
    if ($checkInput.prop('checked')) {
      const $tag = $(`<span class="selected-tag" tabindex="0" data-acc-parents="${accParents}">${label}</span>`)
      const $removeIcon = $('<span role="button" class="remove-tag" tabindex="0" title="remove tag"><i class="fa-regular fa-xmark"></i></span>');

      // Add remove handler to the tag
      $removeIcon.on('click', () => {
        $checkInput.prop('checked', false).trigger('change'); // Uncheck and trigger change
      });

      $tag.append($removeIcon);

      // Append the tag to the container
      selectedTagsContainer.append($tag);
    } else {
      // If checkbox is unchecked, remove the corresponding tag
      selectedTagsContainer.find('.selected-tag').each(function () {
        const tagAccParents = $(this).data('acc-parents').trim();
        const [grandParentAcc, parentAcc] = tagAccParents.split("___");
        const labelText = $(this).text().trim();
        const isChild = grandParentAcc ? grandParentAcc === grandParentAccTitle && parentAcc === parentAccTitle : parentAcc === parentAccTitle;

        if (isChild && labelText === label) {
          $(this).remove();
        }
      });
    }

    if (selectedTagsContainer.text().trim().length === 0) {
      multiSelectBtn.find('.dropdown-text').removeClass('d-none');
      selectedTagsContainer.addClass('d-none');
      dropdownElement.removeClass('has-selection');
    } else {
      multiSelectBtn.find('.dropdown-text').addClass('d-none');
      selectedTagsContainer.removeClass('d-none');
      dropdownElement.addClass('has-selection');
    }
  }

  // Show labels if any items are already checked
  $.each(dropdownElement.find('.form-check-input'), function (index, checkInput) {
    showSelectedLabels($(checkInput))
  })

  // Event handler to handle tag creation and removal
  dropdownElement.find('.form-check-input').on('change', function () {
    showSelectedLabels($(this));
  });

  // Add behavior to auto-open the first child accordion when a parent is opened
  dropdownElement.find('.accordion-button').on('click', function () {
    const parentAccordion = $(this).closest('.accordion-item');  // Get the parent accordion
    const firstChildCollapse = parentAccordion.find('.accordion-collapse').first();  // Get the first child accordion collapse

    // If the parent has a child accordion, automatically open the first one
    if (firstChildCollapse.length) {
      firstChildCollapse.collapse('show');
    }
  });

  return dropdownElement;
}


function adminSideMenuFn() {
  // Get the current URL
  var currentUrl = window.location.href;

  // Add 'active' class to the matching anchor tag
  $('.leftMenu a').each(function () {
    var linkUrl = $(this).attr('href');
    if (linkUrl && currentUrl.includes(linkUrl)) {
      $(this).addClass('active');

      // Expand parent menus and remove 'collapsed' class
      $(this)
        .closest('.submenu')
        .addClass('show')
        .prev('.dropdown-toggle')
        .removeClass('collapsed');

      // Expand all parent menus up the hierarchy
      $(this)
        .parents('.submenu')
        .each(function () {
          $(this).addClass('show');
          $(this)
            .prev('.dropdown-toggle')
            .removeClass('collapsed');
        });
    }
  });

  document.addEventListener('show.bs.collapse', function (event) {
    const menuItem = event.target.closest('.menuItem'); // Find the parent .menuItem of the shown submenu
    if (menuItem && !menuItem.classList.contains('nestedMenu')) {
      menuItem.classList.add('active'); // Add the active class
    }
  });

  document.addEventListener('hide.bs.collapse', function (event) {
    const menuItem = event.target.closest('.menuItem'); // Find the parent .menuItem of the hidden submenu
    if (menuItem && !menuItem.classList.contains('nestedMenu')) {
      menuItem.classList.remove('active'); // Remove the active class
    }
  });
  document.addEventListener('show.bs.collapse', function (event) {
    const allSubmenus = document.querySelectorAll('.submenu.collapse');

    allSubmenus.forEach((submenu) => {
      // Close only sibling submenus
      if (submenu !== event.target && !event.target.contains(submenu) && !submenu.contains(event.target)) {
        const bsCollapse = bootstrap.Collapse.getInstance(submenu);
        if (bsCollapse) {
          bsCollapse.hide();
        }
      }
    });
  });

  document.querySelectorAll('.nestedMenu .submenu').forEach((nestedMenu) => {
    nestedMenu.addEventListener('click', function (e) {
      e.stopPropagation(); // Stop the event from propagating to parent dropdown
    });
  });

  $('.navbar-toggler').click(function () {
    // Toggle the collapsed state of the hamburger icon
    $(this).toggleClass('collapsed');

    // Check if the menu is already open
    if ($('.appLeftMenu').is(':visible')) {
      // If the menu is open, slide it closed
      $('.appLeftMenu').hide("slide", { direction: "left" }, 600);
    } else {
      // If the menu is closed, slide it open and set focus to the first element inside
      $('.appLeftMenu').show("slide", { direction: "left" }, 600, function () {
        // Focus on the first focusable element inside the menu (for example, a link)
        $('.appLeftMenu a:first').focus();
      });
    }

    // Toggle the body's overflow-hidden class to prevent scrolling when the menu is open
    $('body').toggleClass('overflow-hidden');
  });

  $(".expandPin").click(function () {
    $(".appRightContent").toggleClass("fullwidth");
    $(".dropdown-toggle").addClass("collapsed");
    $(".submenu").removeClass("show");
    $('.leftMenu .menuItem').removeClass('active');
    const isExpanded = $(this).attr('aria-expanded') === 'true';
    $(this).attr('aria-expanded', !isExpanded);
    $(".appLeftMenu").toggleClass("closed");
  });
  $(".nestedMenu .dropdown-toggle").click(function () {
    let $submenu = $(this).next(".submenu");
    let itemCount = $submenu.find(".menuItem").length;
    console.log(itemCount)
    $submenu.removeClass("medium-list large-list");
    if (itemCount >= 9 && itemCount <= 12) {
      $submenu.addClass("medium-list");
    } else if (itemCount > 12) {
      $submenu.addClass("large-list");
    }
  });


  // $(document).click(function (event) {
  //   let $target = $(event.target);
  //   if (!$target.closest(".submenu, .dropdown-toggle").length) {
  //     $(".submenu").removeClass("show").collapse("hide");
  //     $('.leftMenu .menuItem').removeClass('active');
  //     $(".dropdown-toggle").addClass("collapsed");
  //   }
  // });

  $(window).bind("resize", function () {
    if ($(this).width() > 1200) {
      $('.appLeftMenu').show();
      $('.appLeftMenu').removeClass('slide-opened');
      $('body').removeClass('overflow-hidden');
      $('.navbar-toggler').addClass('collapsed');
    } else {
      if ($('.appLeftMenu').is(':visible')) {
        $('body').addClass('overflow-hidden');
      }
    }
  }).resize();
}

function menuActiveFn() {
  // Get the current URL
  var currentUrl = window.location.pathname.split('/').pop();
  // Loop through each menu item
  $('.leftMenu .menuItem').each(function () {
    let $menuItem = $(this).children('a');
    let href = $menuItem.attr('href');

    // Manually check each case based on `currentUrl` and target href
    if (currentUrl.startsWith('shared-member-') && href === 'shared-member-record.html') {
      $menuItem.addClass('active');
      subMenuCollapse($menuItem);
    }
    // Exact URL match
    else if (href === currentUrl) {
      $menuItem.addClass('active');
      subMenuCollapse($menuItem);
    }

    function subMenuCollapse(menuItem) {
      const $submenu = $(menuItem).closest('.submenu');
      const $parentmenu = $(menuItem).parents('.submenu');
      if ($submenu.length) {
        $submenu.collapse('show');
        $parentmenu.collapse('show');
      }
    }
  });
}

function collapseAllChildRows() {
  $('.childElement').each(function () {
    $(this).hide(); // Hide all rows with the 'childElement' class
  });

  $('.actionselect').hide();
  if ($('.actionselect .selected-values').find('.selected-tag').length > 0) {
    $('.actionselect').show();
  } else {
    $('.actionselect').hide();
  }

}

function showCurrentYear() {
  $('#spanYear').html(new Date().getFullYear());
  $('.errorMessage .error').each(function () {
    console.log($(this).attr('id'))
    $(this).removeAttr('for')
  })
}
function applyShorteningAndTooltip() {
          function shortenSentence(sentence) {
              const limit = 40;
              if (sentence.length > limit) {
                  return sentence.substring(0, 34) + "...";
              }
              return sentence;
          }

          // Select all elements with the class 'charaCount'
          const sentenceCells = document.querySelectorAll('.charaCount');

          // Iterate over each element and shorten the sentence
          sentenceCells.forEach(cell => {
              // Extract the original sentence and trim whitespace
              const originalSentence = cell.textContent.trim();
              const shortenedSentence = shortenSentence(originalSentence);

              // Update the text content with the shortened sentence
              cell.childNodes[0].textContent = shortenedSentence + " ";

              // // Update the tooltip title with the original sentence
              // const tooltipLink = cell.querySelector('.customTooltip');
              // tooltipLink.setAttribute('title', originalSentence);
              // tooltipLink.setAttribute('data-bs-title', originalSentence);

              // Set max width for the cell
              //cell.style.maxWidth = '350px';
              // cell.style.overflow = 'hidden';
              // cell.style.textOverflow = 'ellipsis';
              // cell.style.whiteSpace = 'nowrap';
          });
} 

 
export { applyAriaAttributesToSelect2, applyErrorAriaDescribedby, initializeSelect2, filterRow, filter, customMultiSelect, inputWithDropdown, tblPaginateDrawCallback, stepper, initializeSelect2ForResponsive, handleTabScrollLeftRight, handleTableCheckbox, customFileUploader, inputPassword, adjustFixedColumnsResponsive, formBuilder, handleRowActions, addContent, multiSelectWithAccordionBuilder, menuActiveFn, adminSideMenuFn, collapseAllChildRows, initCalendar, redirectPage, formValidation, galleryFn, tableAllSelectFn, customPopoverMenu, showCurrentYear, applyShorteningAndTooltip };

