// main.shell.ts
import { createApplication } from '@angular/platform-browser';
import { createCustomElement } from '@angular/elements';
import { AppShellComponent } from './app/app-shell.component';
import { importProvidersFrom, inject, Injector } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { AuthInterceptor } from './app/auth.interceptor';
import { CookieService } from 'ngx-cookie-service';
import { JwtHelperService, JWT_OPTIONS } from '@auth0/angular-jwt';

createApplication({
  providers: [
    provideHttpClient(
      withInterceptors([
        (req, next) => {
          const injector = inject(Injector);
          const interceptor = injector.get(AuthInterceptor);
          return interceptor.intercept(req, { handle: next });
        }
      ])
    ),
    importProvidersFrom(BrowserModule, BrowserAnimationsModule),
    AuthInterceptor,
    CookieService,
    JwtHelperService,
    {
      provide: JWT_OPTIONS,
      useFactory: () => ({
        tokenGetter: () => inject(CookieService).get('access_token'),
        allowedDomains: ['gbsuk-apim-dev.ajg.com']
      })
    }
  ]
}).then(app => {
  const customElement = createCustomElement(AppShellComponent, { injector: app.injector });

  if (!customElements.get('app-my-widget')) {
    customElements.define('app-my-widget', customElement);
  }
});
