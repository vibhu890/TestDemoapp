export interface Client {
  book: string;
  code: string;
  name: string;
  sic: string;
 clientId:string
}