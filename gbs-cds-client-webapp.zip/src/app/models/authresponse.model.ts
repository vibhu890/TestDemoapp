export interface AuthResponse{
    Authorization_Details:AuthorizationDetails;
}
export interface AuthorizationDetails{
    personId?:string;
    loginClientId?:string;
    userType?:string;
    userLoginId?:string;
    clients?:Clients[];
}
export interface Clients{
    clientId?:string;
    clientName?:string
    subGroups?:any; 
    modules?:Modules[];
}
export interface Modules{
    moduleID?:string;
    moduleDescription?:string;
    roles?:Roles;
}
export interface Roles{
    roleID?:string;
    roleDescription?:string;
    features?:Features[];
}
export interface Features{
    featureID?:string;
    featureDescription?:string;
    featurePermission?:SubFeaturePermission; //change accordingly
    subFeatures?:SubFeatures[];
}
export interface SubFeatures{
    subFeatureID?:string;
    subFeatureDescription?:string;
    subFeaturePermission?:SubFeaturePermission;
}
export interface SubFeaturePermission{
    permissionId:string;
    permissionType:string;
}

export interface featureList{
    featureID?:string;
    featureDescription?:string;
}