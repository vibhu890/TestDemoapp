export interface UpsertClientDetail{
  Books:BookPayload[]
}

export interface BookPayload {
  BookId?: string;
  BookName: string;
  Clients: Client;
}

export interface Client {
  ClientId?: string; // Optional for insert
  ClientName: string;
  SicCode?: number;
  DomainClientId?: string;
  ClientCode: string;
  Services: Service[];
  Languages: Language[];
  [key: string]: any;
}

export interface Service {
  PlatformId?: string; // Optional for insert
  PlatformName: string;
  ServiceId?: string; // Optional for insert
  ServiceName: string;
  DomainClientId: string;
  Address: Address;
}

export interface Address {
  Address1: string;
  Address2?: string;
  Address3?: string;
  City: string;
  State?: string;
  Country: string;
  PostalCode: string;
}

export interface Language {
  CountryCode: string;
  CountryName: string;
  LanguageCode: string;
  LanguageName: string;
  CultureName: string;
  LanguageLocaleName: string;
  IsDefaultLanguage: boolean;
  LanguageCustomDisplayName?: string;
  Services: LanguageService[];
}

export interface LanguageService {
  ServiceId: string;
  ServiceName: string;
}
