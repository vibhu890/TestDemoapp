import { TestBed } from '@angular/core/testing';
import { AuthInterceptor } from './auth.interceptor';
import { HttpRequest, HttpHandler } from '@angular/common/http';
import { EMPTY } from 'rxjs';

let interceptor: AuthInterceptor;

beforeEach(() => {
  TestBed.configureTestingModule({});
  interceptor = new AuthInterceptor();
});

it('should be created', () => {
  expect(interceptor).toBeTruthy();
});

it('should call intercept method', () => {
  const req = new HttpRequest('GET', '/test');
  const next: HttpHandler = {
    handle: jasmine.createSpy('handle').and.callFake(() => EMPTY)
  };

  interceptor.intercept(req, next);
  expect(next.handle).toHaveBeenCalledWith(req);

});