import { Component, EventEmitter, Input, OnInit, Output, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { AuthService } from '../../services/auth.service';
 
@Component({
  selector: 'app-client-language',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatCheckboxModule,
    MatButtonModule,
    MatIconModule
  ],
  templateUrl: './client-language.component.html',
  styleUrls: ['./client-language.component.scss']
})
export class ClientLanguageComponent implements OnInit{
    hasEditAccess = false;
  hasViewAccess = false;
  showLoader = true;
  @Input() languageData: any[] = [];
  @Output() dataChanged = new EventEmitter<any[]>();
  @Output() previous = new EventEmitter<void>();
  @Output() next = new EventEmitter<void>();
  @Output() cancelAction = new EventEmitter<void>();
  @Output() reviewAndSave = new EventEmitter<void>();
 
  languages: any[] = [];
  private authService = inject(AuthService);
  ngOnInit() {
     this.setPermissionForModule();
  }
 
  addLanguageRow() {
    const newLanguage = {
      country: '',
      language: '',
      cultureName: '',
      isDefaultLanguage: false,
      services: ''  // Can be a comma-separated string or a list depending on UI
    };
    this.languages.push(newLanguage);
    this.emitDataChange();
  }
 
  removeLanguageRow(index: number) {
    this.languages.splice(index, 1);
    this.emitDataChange();
  }
 
    setPermissionForModule(): void {
    this.authService.getRolePermisssion('User Management').subscribe((permission: string) => {
      if (permission === 'Edit') {
        this.hasEditAccess = true;
        this.hasViewAccess = true;
      } else if (permission === 'View') {
        this.hasEditAccess = false;
        this.hasViewAccess = true;
      } else {
        this.hasEditAccess = false;
        this.hasViewAccess = false;
      }
 
      this.showLoader = false;
    });
  }
 
  emitDataChange() {
    this.dataChanged.emit(this.languages);
  }
 
  goPrevious() {
    this.previous.emit();
  }
 
  goNext() {
    //this.emitDataChange();
    this.next.emit();
  }
 
  cancelChanges() {
    this.cancelAction.emit();
  }
 
 goToReviewTab() {
    this.reviewAndSave.emit();  
  }
  reviewAndSaveClick() {
    this.emitDataChange();
    this.reviewAndSave.emit();
  }
 
  onLanguageChange(index: number, field: string, value: any) {
    this.languages[index][field] = value;
    this.emitChanges();
  }
 
  emitChanges() {
    this.dataChanged.emit(this.languages);
  }
}