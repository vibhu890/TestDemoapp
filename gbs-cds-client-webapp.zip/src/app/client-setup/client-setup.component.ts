import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTabsModule } from '@angular/material/tabs';
import { ClientBasicComponent } from './client-basic/client-basic.component';
import { ClientServicesComponent } from './client-services/client-services.component';
import { ClientLanguageComponent } from './client-language/client-language.component';
import { ClientReviewComponent } from './client-review/client-review.component';
import { AuthService } from '../services/auth.service';
import { ClientService } from '../services/client.service';
import { throwError } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { DialogComponent } from '../shared/dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { BookPayload, Language } from '../models/upsertclientdata.model';

@Component({
  selector: 'app-client-setup',
  standalone: true,
  imports: [
    CommonModule,
    MatTabsModule,
    ClientBasicComponent,
    ClientServicesComponent,
    ClientLanguageComponent,
    ClientReviewComponent
  ],
  templateUrl: './client-setup.component.html',
  styleUrls: ['./client-setup.component.scss']
})

export class ClientSetupComponent implements OnInit {
  hideLanguageTab = false;
  isReadOnly = false;
  selectedTab = 0;
  hasEditPermission = false;
  hasViewPermission = false;
  showLoader = true;
  serviceData: any
  bookList:any
  clientData: BookPayload = {
    BookId:'',
    BookName: '',
    Clients: {
      ClientId: '',
      ClientName: '',
      SicCode: 0,
      DomainClientId: '',
      ClientCode: '',
      Services: [],
      Languages: []
    }
  };
  private authService = inject(AuthService);
  private clientService = inject(ClientService);
  private route = inject(ActivatedRoute);
  private dialog = inject(MatDialog);

  selectedClientId = '';
  books: string[]= [];
  ngOnInit(): void {
      this.route.queryParams.subscribe(params => {
      this.selectedClientId = params['clientId'] || '';
    });
    this.setPermissionForModule();
    this.getLanguagesData();
    this.getAllServicesData();
     this.loadBooks();

  }

  loadBooks() {
  this.clientService.getClientList().subscribe({
    next: (res: any) => {
      const clientlist: any[] = [];
      const uniqueBooks: Set<string> = new Set<string>();

      res.forEach((entry: any) => {
        this.bookList = entry.books || [];
        console.log(this.bookList)
        this.bookList.forEach((bookEntry: any) => {
          if (!bookEntry || !bookEntry.bookName || !Array.isArray(bookEntry.clients)) {
            console.warn('Skipping invalid book entry:', bookEntry);
            return;
          }

          const bookName = bookEntry.bookName;
          uniqueBooks.add(bookName);

          bookEntry.clients.forEach((client: any) => {
            clientlist.push({
              book: bookName,
              code: client.clientCode,
              name: client.clientName,
              sic: client.sicCode || '',
              clientId: client.clientId
            });
          });
        });
      });

      this.books = Array.from(uniqueBooks);

      if (this.selectedClientId) {
        const client = clientlist.find(c => c.clientId === this.selectedClientId);
        if (client) {
          this.clientData = {
            BookName: client.book,
            Clients:{
            ClientId: client.clientId,
            ClientCode: client.code,
            ClientName: client.name,
            SicCode: client.sic,
            Services: [],
            Languages: []
            }
          };
        }
      }
      else{
        this.clientData.BookName='';
      }
      console.log("Books for dropdown:", this.books);
    },
    error: (err) => {
      console.error('Error fetching book list:', err);
    }
  });
}

  public getLanguagesData() {
    this.clientService.getAllLanguages({}).subscribe({
      next: (res => this.clientData.Clients.Languages = res.languages),
      error: (err => throwError(err))
    })
  }

  updateBookName(bookName: string) {
    this.clientData.BookName = bookName;
  }


  public getAllServicesData() {
    this.clientService.getAllServices().subscribe({
      next: ((res) => this.clientData.Clients.Services = res.services),
      error: (err => throwError(err))
    })
  }


  setPermissionForModule(): void {
    this.authService.getRolePermisssion('Client Setup').subscribe((permission: string) => {
      console.log('Permission for Client Setup:', permission);

      if (permission !== 'No Access') {
        this.showLoader = false;
      }

      if (permission === 'Edit') {
        this.hasEditPermission = true;
      } else if (permission === 'View') {
        this.hasViewPermission = true;
      }
    });
  }

  updateClientData(updatedData: any) {
    this.clientData = { ...this.clientData, ...updatedData };
    this.clientData.BookId = ''
  }

  onCancel() {
    if (confirm('Are you sure you want to cancel?')) {
      this.clientData = {
        BookId:'',
        BookName: '',
        Clients: {
          ClientId: '',
          ClientName: '',
          SicCode: 0,
          DomainClientId: '',
          ClientCode: '',
          Services: [],
          Languages: []
        }
      };
      this.selectedTab = 0;
    }
  }

  onSave() {
    const filteredBook = this.bookList.filter((book:any) => this.clientData.BookName == book.bookName)
    this.clientData.BookId = filteredBook[0].bookId;
    const payload = {
      Books: [this.clientData]
    };
    payload.Books[0].Clients.DomainClientId = '2698'
    payload.Books[0].Clients.Languages = [];
    payload.Books[0].Clients.Services = [];
    this.clientService.saveAllClientData(payload).subscribe({
      next: () => {
          this.dialog.open(DialogComponent, {
                data: {
                  title: 'Confirmation',
                  message: 'Client data saved successfully',
                  buttonText: 'OK'
                },
                width: '400px',
                disableClose: true
              });
      },
      error: (err) => { throwError(err) }
    })
  }

  updateLanguageData(updatedLanguageData: Language[]) {
    this.clientData.Clients.Languages = updatedLanguageData;
  }
  onNextAfterLanguage() {
    alert('Next button clicked on Language tab');
  }

  goToNextTab() {
    if (this.selectedTab < 3) {
      this.selectedTab++;
    }
  }

  goToPreviousTab() {
    if (this.selectedTab > 0) {
      this.selectedTab--;
    }
  }

  goToTab(index: number) {
    this.selectedTab = index;
  }
}