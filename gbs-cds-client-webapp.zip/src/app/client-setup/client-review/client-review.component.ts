import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { BookPayload } from '../../models/upsertclientdata.model';

@Component({
  selector: 'app-client-review',
  standalone: true,
  imports: [CommonModule, MatButtonModule],
  templateUrl: './client-review.component.html',
  styleUrls: ['./client-review.component.scss']
})
export class ClientReviewComponent {
  @Input() clientData!:BookPayload;
  @Output() previous = new EventEmitter<void>();
  @Output() cancelAction = new EventEmitter<void>();
  @Output() save = new EventEmitter<void>();

  confirmCancel() {
    const confirmResult = confirm('Changes not saved will be discarded. Continue?');
    if (confirmResult) {
      this.cancelAction.emit();
    }
  }

  saveChanges() {
    this.save.emit();
  }

  goPrevious() {
    this.previous.emit();
  }
  
}

