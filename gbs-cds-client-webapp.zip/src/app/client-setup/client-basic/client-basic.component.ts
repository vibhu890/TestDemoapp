import { Component, Input, Output, EventEmitter, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { AuthService } from '../../services/auth.service';
import { BookPayload } from '../../models/upsertclientdata.model';

@Component({
  selector: 'app-client-basic',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule
  ],
  templateUrl: './client-basic.component.html',
  styleUrls: ['./client-basic.component.scss']
})
export class ClientBasicComponent implements OnInit {
  @Input() clientData!:BookPayload;
  @Input() readOnly = false;
  @Input() books: string[] =[];
  @Output() dataChanged = new EventEmitter<any>();
  @Output() next = new EventEmitter<void>();
  @Output() cancelAction = new EventEmitter<void>();
  @Output() saveAction = new EventEmitter<void>();
  @Output() reviewAndSave = new EventEmitter<void>();
    isEditMode = false;
  hasEditAccess = false;
  hasViewAccess = false;
  showLoader = true;

  guidPattern = '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$';

  private authService = inject(AuthService);

    @Input() selectedClientId = '';
  ngOnInit(): void {
    this.setPermissionForModule();
    if(this.selectedClientId)
    {
      this.isEditMode=true;
    }
    else
    {
      this.isEditMode=false;
    }
  }

  setPermissionForModule(): void {
    this.authService.getRolePermisssion('User Permissions Managements')
      .subscribe((permission: string) => {
        if (permission === 'Edit') {
          this.hasEditAccess = true;
          this.hasViewAccess = true;
        } else if (permission === 'View') {
          this.hasEditAccess = false;
          this.hasViewAccess = true;
        } else {
          this.hasEditAccess = false;
          this.hasViewAccess = false;
        }
        this.showLoader = false;
      });
  }

  
  onChange(field: keyof BookPayload, value: any) {
    this.clientData[field] = value;
    this.dataChanged.emit(this.clientData);
  }

  emitDataChange() {
    this.dataChanged.emit(this.clientData);
  }

  goNext(form: NgForm) {
    if (form.invalid) {
      Object.keys(form.controls).forEach(field => {
        const control = form.controls[field];
        control.markAsTouched({ onlySelf: true });
      });
      return;
    }
    this.next.emit();
  }

  reviewAndSaveClick() {
    this.emitDataChange();
    this.reviewAndSave.emit();
  }
}
