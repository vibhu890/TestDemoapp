import { Component, EventEmitter, Input, Output, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { OnInit } from '@angular/core';
import { AuthService } from '../../services/auth.service';
 
@Component({
  selector: 'app-client-services',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule
  ],
  templateUrl: './client-services.component.html',
  styleUrls: ['./client-services.component.scss']
})
export class ClientServicesComponent implements OnInit {
    hasEditAccess = false;
  hasViewAccess = false;
  showLoader = true;
  @Input() serviceData: any = { services: [] };
  @Output() dataChanged = new EventEmitter<any>();
  @Output() previous = new EventEmitter<void>();
  @Output() next = new EventEmitter<void>();
  @Output() cancelEvent = new EventEmitter<void>();
  @Output() reviewAndSave = new EventEmitter<void>();
 
  services : any[] = [];
  private authService = inject(AuthService);
  ngOnInit() {
    this.setPermissionForModule();
    console.log(this.serviceData)
  }
 
  availableServices: string[] = ['Service A', 'Service B', 'Service C'];
 
  addServiceRow() {
    const newService = {
      name: '',
      domainId: '',
      address: '',
      platformId: ''
    };
    this.serviceData.services.push(newService);
    this.emitChanges();
  }
 
  removeServiceRow(index: number) {
    this.serviceData.services.splice(index, 1);
    this.emitChanges();
  }
 
  setPermissionForModule() {
  this.authService.getRolePermisssion("User Management").subscribe((permission: string) => {
    if (permission === 'Edit') {
      this.hasEditAccess = true;
      this.hasViewAccess = true;
    } else if (permission === 'View') {
      this.hasViewAccess = true;
    } else {
      this.hasEditAccess = false;
      this.hasViewAccess = false;
    }
  });
}
  onServiceChange(index: number, field: string, value: any) {
    this.serviceData.services[index][field] = value;
    this.emitChanges();
  }
 
  emitChanges() {
    this.dataChanged.emit(this.serviceData);
  }
 
 reviewAndSaveClick() {
    this.emitChanges();
    this.reviewAndSave.emit();
   
  }
 
  goPrevious() {
    this.previous.emit();
  }
 
  goNext() {
    this.next.emit();
  }
 
  cancelChanges() {
    this.cancelEvent.emit();
  }
}