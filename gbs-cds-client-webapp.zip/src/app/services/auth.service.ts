import { Injectable, inject } from '@angular/core';
import { catchError, map, Observable, of, take, switchMap } from 'rxjs';
import { environment } from '../../environments/environment';
import { AuthResponse, featureList } from '../models/authresponse.model';
import { BaseService } from './base.service';
import { HttpClient } from '@angular/common/http';
import { JwtHelperService } from '@auth0/angular-jwt';
import { CookieService } from 'ngx-cookie-service';
import { AuthenticationApiService } from './authentication-api.service';

@Injectable({ providedIn: 'root' })
export class AuthService {
  data!: AuthResponse;
  personId = '';
  featurelist: featureList[] = [];
  enableAuth = environment.enableAuth;
  private cookieService = inject(CookieService);
  private http = inject(HttpClient);
  private baseService = inject(BaseService);
  private jwtHelper = inject(JwtHelperService);
  private authNService = inject(AuthenticationApiService);

  private redirectToUnifiedPortalLogin() {
    // const loginUrl = environment.unifiedPortalLoginUrl;
    console.log('Redirecting to Unified Portal login...');
    // window.location.href = loginUrl; // Uncomment if needed
  }

  getRolePermisssion(featureName: string): Observable<'Edit' | 'View' | 'No Access'> {
    console.log('[AuthService] Checking permission for feature:', featureName);

    const token = this.cookieService.get('access_token');
    if (!token?.trim()) {
      console.warn('Access token missing.');
      this.redirectToUnifiedPortalLogin();
      return of('No Access');
    }

    return this.authNService.validateToken(token).pipe(
      take(1),
      map((resp: any) => {
        if (typeof resp === 'boolean') return resp;
        if (resp && typeof resp.active === 'boolean') return resp.active;
        return false;
      }),
      switchMap((isValid: boolean) => {
        console.log('[AuthService] Token valid:', isValid);
        if (!isValid) {
          this.redirectToUnifiedPortalLogin();
          return of<'Edit' | 'View' | 'No Access'>('No Access');
        }

        if (environment.origins.some(origin => window.location.origin.includes(origin))) {
          this.enableAuth = environment.enableAuth;
          this.personId = '00D8BFFD-330C-4CBA-A7F2-BB676C0B0167';
          console.log('[AuthService] Origin matched. Auth enabled:', this.enableAuth, 'PersonID:', this.personId);
        } else {
          this.enableAuth = true;
          this.personId = '';
          console.log('[AuthService] Origin not matched. Defaulting to Auth enabled:', this.enableAuth);
        }

        this.baseService.setTokenHeader(this.enableAuth);

        if (!this.enableAuth) {
          console.log('[AuthService] Auth disabled. Returning Edit access by default.');
          return of<'Edit' | 'View' | 'No Access'>('Edit');
        }

        return this.getPermission(this.personId).pipe(
          map((response: AuthResponse) => {
            console.log('[AuthService] Authorization response:', response);

            const permission = response?.Authorization_Details?.clients
              ?.flatMap(client => client.modules || [])
              ?.find(module => module.moduleDescription === 'Permissions Management')
              ?.roles?.features
              ?.find(feature => feature.featureDescription === featureName)
              ?.featurePermission?.permissionType;

            console.log('[AuthService] Raw permission type:', permission);

            if (permission === 'Edit' || permission === 'Publish') return 'Edit';
            if (permission === 'View') return 'View';
            return 'No Access';
          }),
          catchError(err => {
            console.error('[AuthService] Error during permission check:', err);
            return of<'Edit' | 'View' | 'No Access'>('No Access');
          })
        );
      }),
      catchError(err => {
        console.error('[AuthService] Token validation failed:', err);
        this.redirectToUnifiedPortalLogin();
        return of<'Edit' | 'View' | 'No Access'>('No Access');
      })
    );
  }

  getPermission(personId: string): Observable<AuthResponse> {
    console.log('[AuthService] Fetching permission for PersonID:', personId);
    return this.baseService.GET(`GetAuthorizationDetails_V1?PersonID=${personId}`).pipe(
      map((data: AuthResponse) => {
        console.log('[AuthService] Permission API response:', data);
        return data;
      }),
      catchError(err => {
        console.error('[AuthService] Error in getPermission API:', err);
        return of({} as AuthResponse);
      })
    );
  }
  clearFeatureList(): void {
    setTimeout(() => {
      sessionStorage.removeItem('Featurelist');
    }, environment.featureclearTimeout);
  }
}