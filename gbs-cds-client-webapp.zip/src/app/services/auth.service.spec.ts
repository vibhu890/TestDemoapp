// import { AuthService } from './auth.service';
// import { BaseService } from './base.service';
// import { of, throwError } from 'rxjs';
// import { AuthResponse } from '../models/authresponse.model';
// import { environment } from '../../environments/environment';

// describe('AuthService', () => {
//   let service: AuthService;
//   let mockBaseService: jest.Mocked<BaseService>;

//   const mockSessionStorage = {
//     getItem: jest.fn(),
//     setItem: jest.fn(),
//     removeItem: jest.fn()
//   };

//   beforeEach(() => {
//     mockBaseService = {
//       GET: jest.fn().mockReturnValue(of([])), // Default stub to avoid .pipe() issues
//       setTokenHeader: jest.fn()
//     } as any;

//     Object.defineProperty(globalThis, 'sessionStorage', {
//       value: mockSessionStorage,
//       writable: true
//     });

//     jest.spyOn(document, 'baseURI', 'get').mockReturnValue('https://example.com/');

//     service = new AuthService({} as any, mockBaseService);

//     jest.useFakeTimers();
//     environment.origins = ['example.com'];
//     environment.enableAuth = true;
//     environment.personId = 'person123';
//     environment.featureclearTimeout = 500;
//   });

//   describe('getFeatureList', () => {
//     it('should fetch and cache feature list', () => {
//       const features = [{ featureID: 'x1', featureDescription: 'desc' }];
//       mockBaseService.GET.mockReturnValue(of(features));

//       service['getFeatureList']().subscribe(data => {
//         expect(data).toEqual(features);
//         expect(mockSessionStorage.setItem).toHaveBeenCalledWith('Featurelist', JSON.stringify(features));
//       });

//       jest.advanceTimersByTime(environment.featureclearTimeout);
//       expect(mockSessionStorage.removeItem).toHaveBeenCalledWith('Featurelist');
//     });

//     it('should return empty list on error', () => {
//       mockBaseService.GET.mockReturnValue(throwError(() => new Error()));
//       service['getFeatureList']().subscribe(data => {
//         expect(data).toEqual([]);
//       });
//     });
//   });

//   describe('getFeatureId', () => {
//     it('should return feature ID from cache', () => {
//       const list = [{ featureID: 'id1', featureDescription: 'TestFeature' }];
//       mockSessionStorage.getItem.mockReturnValue(JSON.stringify(list));

//       service.getFeatureId('TestFeature').subscribe(id => {
//         expect(id).toBe('id1');
//       });
//     });

//     it('should fetch and return feature ID from API', () => {
//       mockSessionStorage.getItem.mockReturnValue(null);
//       const list = [{ featureID: 'id2', featureDescription: 'Another' }];
//       mockBaseService.GET.mockReturnValue(of(list));

//       service.getFeatureId('Another').subscribe(id => {
//         expect(id).toBe('id2');
//       });
//     });

//     it('should return null if not found or error', () => {
//       mockBaseService.GET.mockReturnValue(of([]));
//       service.getFeatureId('Unknown').subscribe(id => {
//         expect(id).toBeNull();
//       });

//       mockBaseService.GET.mockReturnValue(throwError(() => new Error()));
//       service.getFeatureId('ErrorCase').subscribe(id => {
//         expect(id).toBeNull();
//       });
//     });
//   });

//   describe('getPermission', () => {
//     it('should return response from API', () => {
//       const response = { Authorization_Details: { clients: [] } };
//       mockBaseService.GET.mockReturnValue(of(response));

//       service.getPermission('id').subscribe(res => {
//         expect(res).toEqual(response);
//       });
//     });

//     it('should return empty AuthResponse on error', () => {
//       mockBaseService.GET.mockReturnValue(throwError(() => new Error()));
//       const expectedEmpty: AuthResponse = { Authorization_Details: { clients: [] } };

//       service.getPermission('id').subscribe(res => {
//         expect(res).toEqual(expectedEmpty);
//       });
//     });
//   });

//   describe('getRolePermisssion', () => {
//     it('should return Edit if auth disabled', () => {
//       environment.enableAuth = false;

//       // Prevents undefined.pipe crash
//       mockBaseService.GET.mockReturnValue(of([]));

//       service.getRolePermisssion('x').subscribe(res => {
//         expect(res).toBe('Edit');
//       });
//     });

//     it('should return No Access if featureId is null', () => {
//       jest.spyOn(service, 'getFeatureId').mockReturnValue(of(null));
//       service.getRolePermisssion('unknown').subscribe(res => {
//         expect(res).toBe('No Access');
//       });
//     });

//     it('should return permission type from response', () => {
//       const featureID = 'f1';
//       const response = {
//         Authorization_Details: {
//           clients: [{
//             modules: [{
//               moduleDescription: 'Permissions Management',
//               roles: {
//                 features: [{
//                   featureID,
//                   featurePermission: {
//                     permissionId: 'p1',
//                     permissionType: 'View'
//                   }
//                 }]
//               }
//             }]
//           }]
//         }
//       };

//       jest.spyOn(service, 'getFeatureId').mockReturnValue(of(featureID));
//       jest.spyOn(service, 'getPermission').mockReturnValue(of(response));

//       service.getRolePermisssion('TestFeature').subscribe(res => {
//         expect(res).toBe('View');
//       });
//     });
//   });

//   describe('clearFeatureList', () => {
//     it('should remove Featurelist after timeout', () => {
//       service.clearFeatureList();
//       jest.advanceTimersByTime(environment.featureclearTimeout);
//       expect(mockSessionStorage.removeItem).toHaveBeenCalledWith('Featurelist');
//     });
//   });
// });
