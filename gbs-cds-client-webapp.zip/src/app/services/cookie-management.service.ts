import { Injectable, inject } from '@angular/core';
import { AuthenticationApiService } from './authentication-api.service';
import { CookieService } from 'ngx-cookie-service';
import { take } from 'rxjs/operators';
 
@Injectable({
  providedIn: 'root'
})
export class CookieManagementService {
private authNService = inject(AuthenticationApiService);
private cookieService = inject(CookieService);

constructor() {
  this.initSessionTracking();
  console.log('CookieManagementService initialized...');
}
 
  private initSessionTracking() {
    console.log('Initializing session tracking...');
    this.validateTokenAndCheckExpiry();
 
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden) {
        console.log('Tab visible again - checking token validity...');
        this.validateTokenAndCheckExpiry();
      }
    });
 
    window.addEventListener('focus', () => {
      console.log('Window focused - checking token validity...');
      this.validateTokenAndCheckExpiry();
    });
  }
 
  private validateTokenAndCheckExpiry() {
    console.log('Validating token...');
 
    const accessToken = this.cookieService.get('access_token');
    const refreshToken = this.cookieService.get('refresh_token');
 
    if (!accessToken?.trim() || !refreshToken?.trim()) {
      console.warn('Missing token(s)');
      this.redirectToUnifiedPortalLogin();
      return;
    }
 
    this.authNService.validateToken(accessToken).pipe(take(1)).subscribe({
      next: (isValid: boolean) => {
        if (isValid) {
          console.log('Token is valid or successfully refreshed.');
        } else {
          console.warn('Token validation and refresh failed.');
          this.redirectToUnifiedPortalLogin();
        }
      },
      error: (err) => {
        console.error('Unexpected error during token validation:', err);
        this.redirectToUnifiedPortalLogin();
      }
    });
  }
 
  private redirectToUnifiedPortalLogin() {
    //const loginUrl = environment.unifiedPortalLoginUrl;
    console.log('Redirecting to Unified Portal login...');
    // window.location.href = loginUrl;
  }
}