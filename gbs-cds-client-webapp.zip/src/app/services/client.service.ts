import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError, tap, throwError } from 'rxjs';
import { environment } from '../../environments/environment';
import { BaseService } from './base.service';

@Injectable({
  providedIn: 'root'
})
export class ClientService {

  private http = inject(HttpClient);
  private baseService = inject(BaseService);

  public getAllLanguages(payload: any) {
    return this.http.post(
      `${environment.DOWNSTREAM_API_BASE_URL}GetAllLanguages`,
      payload,
      {headers: this.baseService.getHTTPHeadersWithToken()}
    ).pipe(
      tap((res: any) => res),
      catchError(err => {
        console.log(err);
        return throwError(() => err);
      })
    );
  }

  public getAllServices(payload?: any) {
    return this.http.post(
      `${environment.DOWNSTREAM_API_BASE_URL}GetAllServices`,
      payload,
      {headers: this.baseService.getHTTPHeadersWithToken()}
    ).pipe(
      tap((res: any) => res),
      catchError(err => {
        console.log(err);
        return throwError(() => err);
      })
    );
  }

   public getClientList() {
    return this.http.get(
       `${environment.DOWNSTREAM_API_BASE_URL}GetClientList`,
       {headers: this.baseService.getHTTPHeadersWithToken()}
    ).pipe(
      tap((res: any) => res),
      catchError(err => {
        return throwError(() => err);
      })
    );
  }

  public saveAllClientData(clientData:any){
    return this.http.post(
      '/api/SaveAllClientData',
      clientData,
     {headers: this.baseService.getHTTPHeadersWithToken()}
    ).pipe(
      tap((res: any) => res),
      catchError(err => {
        console.log(err);
        return throwError(() => err);
      })
    );
  }
}
