// import { TestBed } from '@angular/core/testing';
// import { BaseService } from './base.service';
// import { HttpClient } from '@angular/common/http';
// import { JwtHelperService } from '@auth0/angular-jwt';
// import { of } from 'rxjs';
// import { environment } from '../../environments/environment';

// describe('BaseService', () => {
//   let service: BaseService;
//   let httpClientMock: jest.Mocked<HttpClient>;

//   beforeEach(() => {
//     httpClientMock = {
//       get: jest.fn(),
//       post: jest.fn(),
//       put: jest.fn(),
//       delete: jest.fn()
//     } as unknown as jest.Mocked<HttpClient>;

//     TestBed.configureTestingModule({
//       providers: [
//         BaseService,
//         { provide: HttpClient, useValue: httpClientMock },
//         { provide: JwtHelperService, useValue: {} }
//       ]
//     });

//     service = TestBed.inject(BaseService);
//   });

//   it('should create the service', () => {
//     expect(service).toBeDefined();
//   });

//   it('should set enableAuth flag', () => {
//     service.setTokenHeader(true);
//     expect(service.enableAuth).toBe(true);
//   });

//   it('should call GET with headers and credentials', () => {
//     httpClientMock.get.mockReturnValue(of({ result: true }));
//     service.GET('/test').subscribe(res => {
//       expect(res.result).toBe(true);
//     });
//     expect(httpClientMock.get).toHaveBeenCalled();
//   });

//   it('should call POST with payload and headers', () => {
//     const data = { key: 'value' };
//     httpClientMock.post.mockReturnValue(of({ status: 'ok' }));
//     service.POST('/test', data).subscribe(res => {
//       expect(res.status).toBe('ok');
//     });
//     expect(httpClientMock.post).toHaveBeenCalledWith(
//       expect.stringContaining('/test'),
//       data,
//       expect.objectContaining({ headers: expect.anything(), withCredentials: true })
//     );
//   });

//   it('should call PUT with data', () => {
//     httpClientMock.put.mockReturnValue(of({ updated: true }));
//     service.PUT('/test', { id: 1 }).subscribe(res => {
//       const typedRes = res as { updated: boolean };
//       expect(typedRes.updated).toBe(true);
//     });

//     expect(httpClientMock.put).toHaveBeenCalled();
//   });

//   it('should call DELETE with param ID', () => {
//     httpClientMock.delete.mockReturnValue(of({ deleted: true }));
//     service.DELETE('/test', 123).subscribe(res => {
//       const typedRes = res as { deleted: boolean };
//       expect(typedRes.deleted).toBe(true);
//     });

//     expect(httpClientMock.delete).toHaveBeenCalledWith(
//       expect.stringContaining('/123'),
//       expect.anything()
//     );
//   });

//   it('should construct headers with config and auth', () => {
//     service.setTokenHeader(true);
//     const headers = service.getHTTPHeadersWithToken();

//     expect(headers.get('Content-Type')).toBe('application/json');
//     expect(headers.get('ENABLE_ACCESSTOKEN_VALIDATION')).toBe('true');

//     if (environment.enableAPIM) {
//       expect(headers.has('Ocp-apim-subscription-key')).toBe(true);
//     }

//     if (environment.origins.some(origin => window.location.origin.includes(origin))) {
//       expect(headers.has('PersonID')).toBe(true);
//     }
//   });
// });
