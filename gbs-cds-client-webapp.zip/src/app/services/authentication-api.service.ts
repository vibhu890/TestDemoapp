import { Injectable,inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { API_RESPONSE_TYPE } from '../constants/application.constant';
import { switchMap, catchError, map } from 'rxjs/operators';
import { CookieService } from 'ngx-cookie-service';
import { environment } from '../../environments/environment';
 
@Injectable({
  providedIn: 'root'
})
export class AuthenticationApiService {
private http = inject(HttpClient);
private cookieService = inject(CookieService);
 
  getHeaders(customHeaders?: Record<string, string>) {
  let headers = new HttpHeaders()
    .set('Content-Type', API_RESPONSE_TYPE)
    .set('Accept', API_RESPONSE_TYPE)
    .set('Content-Security-Policy', "default-src 'self'")
    .set('X-Content-Type-Options', 'nosniff');
  // if (environment.ocpSubscriptionKey) {
    headers = headers.set('Ocp-Apim-Subscription-Key', '7a139c6cb0d04459aa84be86bdb82296');
  // }
 
  if (customHeaders) {
    Object.entries(customHeaders).forEach(([key, value]) => {
      headers = headers.set(key, value);
    });
  }
  return headers;
}
  public validateToken(token: string): Observable<boolean> {
  console.log("validateToken called");
 
  const body = {
    TokenType: 'access_token',
    Token: token,
  };
 
  const headers = this.getHeaders();
 
  return this.http.post<any>(environment.authnCiamApiUrlApim + 'authentication-validate-token', body, { headers }).pipe(
    switchMap((res: any) => {
      console.log('Validation response:', res);
 
      const expiryTime = res?.exp;
      const currentTime = Math.floor(Date.now() / 1000);
      const bufferTime = 120;
 
      if (res?.active && expiryTime) {
        if (expiryTime <= currentTime + bufferTime) {
          console.log('Token is about to expire. Attempting refresh...');
          const accessToken = this.cookieService.get('access_token');
          const refreshToken = this.cookieService.get('refresh_token');
 
          if (!accessToken || !refreshToken) {
            console.warn('Missing tokens for refresh.');
            return of(false);
          }
 
          return this.refreshToken(refreshToken, accessToken).pipe(
            map((refreshRes: any) => {
              if (refreshRes?.access_token && refreshRes?.refresh_token) {
                this.cookieService.set('access_token', refreshRes.access_token);
                this.cookieService.set('refresh_token', refreshRes.refresh_token);
                console.log('Token refreshed successfully.');
                return true;
              } else {
                console.warn('Invalid refresh response.');
                return false;
              }
            }),
            catchError(err => {
              console.error('Refresh token failed:', err);
              return of(false);
            })
          );
        } else {
          console.log('Token is valid.');
          return of(true);
        }
      } else {
        console.warn('Token is invalid. Attempting refresh...');
        const accessToken = this.cookieService.get('access_token');
        const refreshToken = this.cookieService.get('refresh_token');
 
        if (!accessToken || !refreshToken) {
          console.warn('Missing tokens for refresh.');
          return of(false);
        }
 
        return this.refreshToken(refreshToken, accessToken).pipe(
          map((refreshRes: any) => {
            if (refreshRes?.access_token && refreshRes?.refresh_token) {
              this.cookieService.set('access_token', refreshRes.access_token);
              this.cookieService.set('refresh_token', refreshRes.refresh_token);
              console.log('Token refreshed successfully.');
              return true;
            } else {
              console.warn('Invalid refresh response.');
              return false;
            }
          }),
          catchError(err => {
            console.error('Refresh token failed:', err);
            return of(false);
          })
        );
      }
    }),
    catchError(err => {
      console.error('Token validation failed:', err);
      return of(false);
    })
  );
}
 
  refreshToken(refreshToken: string, accessToken: string): Observable<any> {
  console.log("Refresh Token is called")
    const body = {
    RefreshToken: refreshToken,
    AuthenticationToken: accessToken
  };
 
  const headers = new HttpHeaders({
    'Content-Type': 'application/json'
  });
 
  return this.http.post(environment.authnCiamApiUrl +'authentication-refresh-token', body, { headers });
}
 
 
}