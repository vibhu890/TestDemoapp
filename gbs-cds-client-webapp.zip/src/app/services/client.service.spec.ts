// import { ClientService } from './client.service';
// import { HttpClient } from '@angular/common/http';
// import { of, throwError } from 'rxjs';
// import { API_BASE_URL } from '../constants/application.constant';

// describe('ClientService', () => {
//   let service: ClientService;
//   let httpMock: jest.Mocked<HttpClient>;

//   beforeEach(() => {
//     httpMock = {
//       post: jest.fn()
//     } as unknown as jest.Mocked<HttpClient>;

//     service = new ClientService(httpMock);
//   });

//   describe('getAllLanguages', () => {
//     it('should call POST with correct URL and payload', () => {
//       const mockPayload = { region: 'Asia' };
//       const mockResponse = ['English', 'Hindi'];
//       httpMock.post.mockReturnValue(of(mockResponse));

//       service.getAllLanguages(mockPayload).subscribe(res => {
//         expect(res).toEqual(mockResponse);
//       });

//       expect(httpMock.post).toHaveBeenCalledWith(
//         `${API_BASE_URL}GetAllLanguages`,
//         mockPayload
//       );
//     });

//     it('should handle error response', done => {
//       const error = { status: 500, message: 'Server error' };
//       httpMock.post.mockReturnValue(throwError(() => error));

//       service.getAllLanguages().subscribe({
//         error: err => {
//           expect(err).toEqual(error);
//           done();
//         }
//       });
//     });
//   });

//   describe('getAllServices', () => {
//     it('should call POST with correct URL and payload', () => {
//       const mockPayload = { category: 'Health' };
//       const mockResponse = ['Doctor', 'Pharmacy'];
//       httpMock.post.mockReturnValue(of(mockResponse));

//       service.getAllServices(mockPayload).subscribe(res => {
//         expect(res).toEqual(mockResponse);
//       });

//       expect(httpMock.post).toHaveBeenCalledWith(
//         `${API_BASE_URL}GetAllServices`,
//         mockPayload
//       );
//     });

//     it('should handle error response', done => {
//       const error = { status: 404, message: 'Not found' };
//       httpMock.post.mockReturnValue(throwError(() => error));

//       service.getAllServices().subscribe({
//         error: err => {
//           expect(err).toEqual(error);
//           done();
//         }
//       });
//     });
//   });
// });
