import { Injectable,inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { JwtHelperService } from '@auth0/angular-jwt';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class BaseService {
  baseUrl = '';
  enableAuth = false;
  private http = inject(HttpClient);
public jwtHelper = inject(JwtHelperService);

  constructor() {
    // Choose correct base URL
    this.baseUrl = environment.enableAPIM ? environment.apimURL : environment.apiUrl;
    console.log(this.baseUrl)
  }

  setTokenHeader(enableAuth: boolean): void {
    this.enableAuth = enableAuth;
  }

  GET(path: string): Observable<any> {
    return this.http.get<any>(this.baseUrl + path, {
      headers: this.getHTTPHeadersWithToken(),
      withCredentials: true
    });
  }

  POST(path: string, params: any): Observable<any> {
    return this.http.post<any>(this.baseUrl + path, params, {
      headers: this.getHTTPHeadersWithToken(),
      withCredentials: true
    });
  }

  PUT(path: string, putData: any): Observable<object> {
    return this.http.put(this.baseUrl + path, putData, {
      headers: this.getHTTPHeadersWithToken(),
      withCredentials: true
    });
  }

  DELETE(path: string, paramid: number): Observable<object> {
    return this.http.delete(this.baseUrl + path + '/' + paramid, {
      headers: this.getHTTPHeadersWithToken(),
      withCredentials: true
    });
  }

  getHTTPHeadersWithToken(): HttpHeaders {
    let headers = new HttpHeaders().set('Content-Type', 'application/json');

    headers = headers.append('Content-Security-Policy', "default-src 'self'");
    headers = headers.append('X-Content-Type-Options', 'nosniff');

    if (environment.enableAPIM) {
      headers = headers.append('Ocp-apim-subscription-key', 'ffd55311bf20498695fba1d47ef3e77e');
    }

    if (environment.origins.some(origin => window.location.origin.includes(origin))) {
      console.log('PersonID', '00D8BFFD-330C-4CBA-A7F2-BB676C0B0167')
      headers = headers.append('PersonID', '00D8BFFD-330C-4CBA-A7F2-BB676C0B0167');
    }

    headers = headers.append('ENABLE_ACCESSTOKEN_VALIDATION', this.enableAuth.toString());

    return headers;
  }
}
