import { Injectable, inject } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse } from '@angular/common/http';
import { EMPTY, Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Router } from '@angular/router';
import { environment } from '../environments/environment';
import { CookieService } from 'ngx-cookie-service';
import { MatDialog } from '@angular/material/dialog';
import { DialogComponent } from './shared/dialog.component';

@Injectable({
  providedIn: 'root'
})
export class AuthInterceptor implements HttpInterceptor {
  private router = inject(Router);
  private cookieService = inject(CookieService);
  private dialog = inject(MatDialog);
  constructor() {
    console.log('AuthInterceptor initialized');
  }
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> { 
    const accessToken = this.cookieService.get('access_token');
    const refreshToken = this.cookieService.get('refresh_token');

    if (!accessToken?.trim() || !refreshToken?.trim()) {
      console.warn('Missing access or refresh token. Redirecting to Unified Portal login...');
      
      this.dialog.open(DialogComponent, {
        data: {
          title: 'Session Expired',
          message: 'Your session has expired or tokens are missing. You will be redirected to the login page.',
          buttonText: 'OK'
        },
        width: '400px',
        disableClose: true
      });

      this.redirectToUnifiedPortalLogin();
      return EMPTY;
    }

    console.log("interceptor token",accessToken);
    let clonedRequest = req;
    console.log("This is Interceptor",clonedRequest);
    if (environment.enableAuthnCiamAPIM && environment.enableAuthnDataConfigAPIM && accessToken) {
      clonedRequest = req.clone({
        setHeaders: {
          AccessToken: `${accessToken}`
        }
      });
    }

    return next.handle(clonedRequest).pipe(
      catchError((error: HttpErrorResponse) => {
        if(error.status === 401){
          console.log("Interceptor Unauthorize",error.status)
          this.redirectToUnifiedPortalLogin();
        }
        return throwError(() => error);
      })
    );
  }
   private redirectToUnifiedPortalLogin() {
    //const loginUrl = environment.unifiedPortalLoginUrl;
    console.log('Redirecting to Unified Portal login...');
    //window.location.href = loginUrl;
  }
}


