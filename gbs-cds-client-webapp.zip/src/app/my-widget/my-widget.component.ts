import { Component } from '@angular/core';

@Component({
  selector: 'app-my-widget',
  standalone: true,
  template: `<h2>Hello from My Widget!</h2>`,
})
export class MyWidgetComponent {
  constructor() {
  console.log('MyWidgetComponent initialized');
}

}
