import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { RouterModule, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { Client } from '../models/client.model';
import { AuthService } from '../services/auth.service';
import { JwtHelperService } from '@auth0/angular-jwt';
import { ClientService } from '../services/client.service';

@Component({
  selector: 'app-client-list',
  standalone: true,
  providers: [JwtHelperService],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule,
    MatTableModule,
    MatButtonModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule
  ],
  templateUrl: './client-list.component.html',
  styleUrls: ['./client-list.component.scss']
})
export class ClientListComponent implements OnInit {
  private clientService = inject(ClientService);
  private router = inject(Router);
  private authService = inject(AuthService);

  clients: Client[] = [];
  books: string[] = [];
  paginatedClients: Client[] = [];
  filterTableData: Client[] = [];
  displayedColumns: string[] = ['book', 'code', 'name', 'sic', 'actions'];
  selectedBook = '';
  filterText = '';
  filterName = '';
  filterCode = '';
  filterBook = '';
  filterSIC='';
  currentPage = 1;
  rowsPerPage = 10;
  totalPages = 0;
  pageSizes = [10,15,20,25,30];
  sortField = '';
  sortOrder = 1;
  permission: 'Edit' | 'View' | 'No Access' = 'No Access';
  ngOnInit() {
    console.log("ngOnInit called client List");
    this.setPermissionForModule();
    
  }

 setPermissionForModule(): void {

    this.authService.getRolePermisssion('User Management').subscribe((permission: 'Edit' | 'View' | 'No Access') => {
    this.permission = permission;
    if (permission === 'No Access') {
      this.clients = [];
      return;
    }

    this.clientService.getClientList().subscribe({
      next: (res) => {
        const clientlist: Client[] = [];
        const uniqueBooks = new Set<string>();
        res.forEach((entry: any) => {
          const bookList = entry.books || [];

          bookList.forEach((bookEntry: any) => {
            if (!bookEntry || !bookEntry.bookName || !Array.isArray(bookEntry.clients)) {
              console.warn('Skipping invalid book entry:', bookEntry);
              return;
            }
            const bookName = bookEntry.bookName;
            uniqueBooks.add(bookName);
            bookEntry.clients.forEach((client: any) => {
              clientlist.push({
                book: bookName,
                code: client.clientCode,
                name: client.clientName,
                sic: client.sicCode || '',
                clientId: client.clientId
              });
            });
          });
        });

        this.clients = clientlist;
        this.books = Array.from(uniqueBooks);
        this.applyFilters();
        console.log("client lists",this.clients)
        console.log("Book List",this.books);
      },
      error: (err) => {
        console.error('Error fetching client list:', err);
      }
    });
  });
}

  createClient() {
    this.router.navigate(['/client-setup']);
  }

  editClient(clientId: string) {
  this.router.navigate(['/client-setup'], { queryParams: { clientId } });
}


  exportClient(client: Client) {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(client));
    const a = document.createElement('a');
    a.href = dataStr;
    a.download = `Client-${client.code}.json`;
    a.click();
  }

  get filteredClients(): Client[] {
    const filtered = this.clients.filter(c =>
      (!this.selectedBook || c.book === this.selectedBook) &&
      (!this.filterText || c.name.toLowerCase().includes(this.filterText.toLowerCase()) || c.code.toLowerCase().includes(this.filterText.toLowerCase()))
    );

    const startIndex = (this.currentPage - 1) * this.rowsPerPage;
    return filtered.slice(startIndex, startIndex + this.rowsPerPage);
  }
 
  applyFilters(): void {
    let filtered = [...this.clients];

     if (this.filterBook.trim()) {
      const bookFilter = this.filterBook.trim().toLowerCase();
      filtered = filtered.filter(c => c.book.toLowerCase().includes(bookFilter));
    }

    if (this.filterCode.trim()) {
      const codeFilter = this.filterCode.trim().toLowerCase();
      filtered = filtered.filter(c => c.code.toLowerCase().includes(codeFilter));
    }

    if (this.filterName.trim()) {
      const nameFilter = this.filterName.trim().toLowerCase();
      filtered = filtered.filter(c => c.name.toLowerCase().includes(nameFilter));
    }

    if (this.filterSIC.trim()) {
      const sicFilter = this.filterSIC.trim().toLowerCase();
      filtered = filtered.filter(c => c.sic.toLowerCase().includes(sicFilter));
    }

    this.filterTableData = filtered;
    this.currentPage = 1;
    this.sortData();
    this.paginateData();
  }


sortData(): void {
  if (!this.sortField) return;
  const field = this.sortField as keyof Client;
  this.filterTableData.sort((a, b) => {
    const valA = a[field] ?? '';
    const valB = b[field] ?? '';
    if (typeof valA === 'string' && typeof valB === 'string') {
      return this.sortOrder * valA.localeCompare(valB);
    }
    return 0;
  });
}

   paginateData(): void {
    const totalItems = this.filterTableData.length;
    this.totalPages = totalItems === 0 ? 0 : Math.ceil(totalItems / this.rowsPerPage);
    if (this.currentPage > this.totalPages) this.currentPage = this.totalPages;
    const startIndex = (this.currentPage - 1) * this.rowsPerPage;
    const endIndex = startIndex + this.rowsPerPage;
    this.paginatedClients = this.filterTableData.slice(startIndex, endIndex);
  }

  onCustomSort(field: string): void {
    if (this.sortField === field) {
      this.sortOrder = -this.sortOrder;
    } else {
      this.sortField = field;
      this.sortOrder = 1;
    }
    this.sortData();
    this.paginateData();
  }

  onPageSizeChange(value: number): void {
    this.rowsPerPage = value;
    this.currentPage = 1;
    this.paginateData();
  }
  clearFilter(): void {
    this.filterBook = '';
    this.filterCode = '';
    this.filterName = '';
    this.filterSIC=''
    this.applyFilters();
    this.rowsPerPage = 10;
    this.onFilter();
  }
  onFilter(currentPage = 1): void {
  const lower = (val: string) => val?.trim().toLowerCase();

  const bookFilter = lower(this.filterBook);
  const codeFilter = lower(this.filterCode);
  const nameFilter = lower(this.filterName);
  const sicFilter = lower(this.filterSIC);

  this.filterTableData = this.clients.filter((client: Client) => {
    return (
      (!bookFilter || client.book.toLowerCase().includes(bookFilter)) &&
      (!codeFilter || client.code.toLowerCase().includes(codeFilter)) &&
      (!nameFilter || client.name.toLowerCase().includes(nameFilter)) &&
      (!sicFilter || client.sic.toLowerCase().includes(sicFilter))
    );
  });

  this.currentPage = currentPage;
  if (this.filterTableData.length === 0) {
    this.currentPage = 0;
  }

  this.sortData();
  this.paginateData();
}
  goToPage(page: number): void {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
      this.paginateData();
    }
  }
  onPageChange(newPage: number): void {

    this.currentPage = newPage;

    this.paginateData();

  }
}
